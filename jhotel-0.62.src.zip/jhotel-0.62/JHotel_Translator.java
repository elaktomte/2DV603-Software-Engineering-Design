/**
 * Copyright 2004, Martin Jungowski
 *Room avai
 *	This file is part of JHotel.
 *
 *	JHotel is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	JHotel is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with JHotel; if not, write to the Free Software
 *	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
**/


import java.awt.Frame;
import java.io.*;
import javax.swing.*;

public class JHotel_Translator extends Frame {

	private javax.swing.JPanel jPanel = null;
	private javax.swing.JLabel jLabel = null;
	private javax.swing.JLabel jLabel1 = null;
	private javax.swing.JLabel jLabel2 = null;
	private javax.swing.JLabel jLabel3 = null;
	private javax.swing.JLabel jLabel4 = null;
	private javax.swing.JLabel jLabel5 = null;
	private javax.swing.JLabel jLabel6 = null;
	private javax.swing.JLabel jLabel7 = null;
	private javax.swing.JLabel jLabel8 = null;
	private javax.swing.JLabel jLabel9 = null;
	private javax.swing.JLabel jLabel10 = null;
	private javax.swing.JLabel jLabel11 = null;
	private javax.swing.JLabel jLabel12 = null;
	private javax.swing.JLabel jLabel13 = null;
	private javax.swing.JLabel jLabel14 = null;
	private javax.swing.JLabel jLabel15 = null;
	private javax.swing.JLabel jLabel16 = null;
	
	private javax.swing.JLabel jLabel17 = null;
	private javax.swing.JLabel jLabel18 = null;
	private javax.swing.JLabel jLabel19 = null;
	private javax.swing.JLabel jLabel20 = null;
	private javax.swing.JLabel jLabel21 = null;
	private javax.swing.JLabel jLabel22 = null;
	private javax.swing.JLabel jLabel23 = null;
	private javax.swing.JLabel jLabel24 = null;
	private javax.swing.JLabel jLabel25 = null;
	private javax.swing.JTextField jTextField = null;
	private javax.swing.JTextField jTextField1 = null;
	private javax.swing.JTextField jTextField2 = null;
	private javax.swing.JTextField jTextField3 = null;
	private javax.swing.JTextField jTextField4 = null;
	private javax.swing.JTextField jTextField5 = null;
	private javax.swing.JTextField jTextField6 = null;
	private javax.swing.JTextField jTextField7 = null;
	private javax.swing.JTextField jTextField8 = null;
	private javax.swing.JTextField jTextField9 = null;
	private javax.swing.JTextField jTextField10 = null;
	private javax.swing.JTextField jTextField11 = null;
	private javax.swing.JTextField jTextField12 = null;
	private javax.swing.JTextField jTextField13 = null;
	private javax.swing.JTextField jTextField14 = null;
	private javax.swing.JTextField jTextField15 = null;
	private javax.swing.JTextField jTextField16 = null;
	private javax.swing.JTextField jTextField17 = null;
	private javax.swing.JTextField jTextField18 = null;
	private javax.swing.JTextField jTextField19 = null;
	private javax.swing.JTextField jTextField20 = null;
	private javax.swing.JTextField jTextField21 = null;
	private javax.swing.JTextField jTextField22 = null;
	private javax.swing.JTextField jTextField23 = null;
	private javax.swing.JTextField jTextField24 = null;
	private javax.swing.JTextField jTextField25 = null;
	private javax.swing.JLabel jLabel26 = null;
	private javax.swing.JLabel jLabel27 = null;
	private javax.swing.JLabel jLabel28 = null;
	private javax.swing.JLabel jLabel29 = null;
	private javax.swing.JLabel jLabel30 = null;
	private javax.swing.JLabel jLabel31 = null;
	private javax.swing.JLabel jLabel32 = null;
	private javax.swing.JLabel jLabel33 = null;
	private javax.swing.JLabel jLabel34 = null;
	private javax.swing.JLabel jLabel35 = null;
	private javax.swing.JLabel jLabel36 = null;
	private javax.swing.JLabel jLabel37 = null;
	private javax.swing.JLabel jLabel38 = null;
	private javax.swing.JTextField jTextField26 = null;
	private javax.swing.JTextField jTextField27 = null;
	private javax.swing.JTextField jTextField28 = null;
	private javax.swing.JTextField jTextField29 = null;
	private javax.swing.JTextField jTextField30 = null;
	private javax.swing.JTextField jTextField31 = null;
	private javax.swing.JTextField jTextField32 = null;
	private javax.swing.JTextField jTextField33 = null;
	private javax.swing.JTextField jTextField34 = null;
	private javax.swing.JTextField jTextField35 = null;
	private javax.swing.JTextField jTextField36 = null;
	private javax.swing.JTextField jTextField37 = null;
	private javax.swing.JTextField jTextField38 = null;

	private javax.swing.JButton jButton = null;
	private javax.swing.JPanel jPanel1 = null;
	private javax.swing.JLabel jLabel39 = null;
	private javax.swing.JLabel jLabel40 = null;
	private javax.swing.JLabel jLabel41 = null;
	private javax.swing.JLabel jLabel42 = null;
	private javax.swing.JLabel jLabel43 = null;
	private javax.swing.JLabel jLabel44 = null;
	private javax.swing.JLabel jLabel45 = null;
	private javax.swing.JLabel jLabel46 = null;
	private javax.swing.JLabel jLabel47 = null;
	private javax.swing.JLabel jLabel48 = null;
	private javax.swing.JLabel jLabel49 = null;
	private javax.swing.JLabel jLabel50 = null;
	private javax.swing.JLabel jLabel51 = null;
	private javax.swing.JTextField jTextField39 = null;
	private javax.swing.JTextField jTextField40 = null;
	private javax.swing.JTextField jTextField41 = null;
	private javax.swing.JTextField jTextField42 = null;
	private javax.swing.JTextField jTextField43 = null;
	private javax.swing.JTextField jTextField44 = null;
	private javax.swing.JTextField jTextField45 = null;
	private javax.swing.JTextField jTextField46 = null;
	private javax.swing.JTextField jTextField47 = null;
	private javax.swing.JTextField jTextField48 = null;
	private javax.swing.JTextField jTextField49 = null;
	private javax.swing.JTextField jTextField50 = null;
	private javax.swing.JTextField jTextField51 = null;
	private javax.swing.JButton jButton1 = null;
	private javax.swing.JButton jButton2 = null;
	private javax.swing.JTextArea jTextArea = null;
	private javax.swing.JTextArea jTextArea1 = null;
	private javax.swing.JTextArea jTextArea2 = null;
	private javax.swing.JTextArea jTextArea3 = null;
	
	
	int count = 119;
	
	
	private javax.swing.JButton jButton3 = null;
	private javax.swing.JPanel jPanel2 = null;
	private javax.swing.JLabel jLabel52 = null;
	private javax.swing.JLabel jLabel53 = null;
	private javax.swing.JTextField jTextField52 = null;
	private javax.swing.JTextField jTextField53 = null;
	private javax.swing.JLabel jLabel54 = null;
	private javax.swing.JLabel jLabel55 = null;
	private javax.swing.JLabel jLabel56 = null;
	private javax.swing.JLabel jLabel57 = null;
	private javax.swing.JLabel jLabel58 = null;
	private javax.swing.JLabel jLabel59 = null;
	private javax.swing.JLabel jLabel60 = null;
	private javax.swing.JLabel jLabel61 = null;
	private javax.swing.JLabel jLabel62 = null;
	private javax.swing.JLabel jLabel63 = null;
	private javax.swing.JLabel jLabel64 = null;
	private javax.swing.JTextField jTextField54 = null;
	private javax.swing.JTextField jTextField55 = null;
	private javax.swing.JTextField jTextField56 = null;
	private javax.swing.JTextField jTextField57 = null;
	private javax.swing.JTextField jTextField58 = null;
	private javax.swing.JTextField jTextField59 = null;
	private javax.swing.JTextField jTextField60 = null;
	private javax.swing.JTextField jTextField61 = null;
	private javax.swing.JTextField jTextField62 = null;
	private javax.swing.JTextField jTextField63 = null;
	private javax.swing.JTextField jTextField64 = null;
	private javax.swing.JLabel jLabel65 = null;
	private javax.swing.JLabel jLabel66 = null;
	private javax.swing.JLabel jLabel67 = null;
	private javax.swing.JLabel jLabel68 = null;
	private javax.swing.JLabel jLabel69 = null;
	private javax.swing.JLabel jLabel70 = null;
	private javax.swing.JLabel jLabel71 = null;
	private javax.swing.JLabel jLabel72 = null;
	private javax.swing.JLabel jLabel73 = null;
	private javax.swing.JLabel jLabel74 = null;
	private javax.swing.JTextField jTextField65 = null;
	private javax.swing.JLabel jLabel75 = null;
	private javax.swing.JLabel jLabel76 = null;
	private javax.swing.JLabel jLabel77 = null;
	private javax.swing.JTextField jTextField66 = null;
	private javax.swing.JTextField jTextField67 = null;
	private javax.swing.JTextField jTextField68 = null;
	private javax.swing.JTextField jTextField69 = null;
	private javax.swing.JTextField jTextField70 = null;
	private javax.swing.JTextField jTextField71 = null;
	private javax.swing.JTextField jTextField72 = null;
	private javax.swing.JTextField jTextField73 = null;
	private javax.swing.JTextField jTextField74 = null;
	private javax.swing.JTextField jTextField75 = null;
	private javax.swing.JTextField jTextField76 = null;
	private javax.swing.JTextField jTextField77 = null;
	private javax.swing.JButton jButton4 = null;
	private javax.swing.JButton jButton5 = null;
	
	private javax.swing.JPanel jPanel3 = null;
	private javax.swing.JLabel jLabel78 = null;
	private javax.swing.JLabel jLabel79 = null;
	private javax.swing.JLabel jLabel80 = null;
	private javax.swing.JLabel jLabel81 = null;
	private javax.swing.JLabel jLabel82 = null;
	private javax.swing.JLabel jLabel83 = null;
	private javax.swing.JLabel jLabel84 = null;
	private javax.swing.JLabel jLabel85 = null;
	private javax.swing.JLabel jLabel86 = null;
	private javax.swing.JLabel jLabel87 = null;
	private javax.swing.JLabel jLabel88 = null;
	private javax.swing.JLabel jLabel89 = null;
	private javax.swing.JLabel jLabel90 = null;
	private javax.swing.JLabel jLabel91 = null;
	private javax.swing.JLabel jLabel92 = null;
	private javax.swing.JLabel jLabel93 = null;
	private javax.swing.JLabel jLabel94 = null;
	private javax.swing.JLabel jLabel95 = null;
	private javax.swing.JLabel jLabel96 = null;
	private javax.swing.JLabel jLabel97 = null;
	private javax.swing.JLabel jLabel98 = null;
	private javax.swing.JLabel jLabel99 = null;
	private javax.swing.JLabel jLabel100 = null;
	private javax.swing.JLabel jLabel101 = null;
	private javax.swing.JLabel jLabel102 = null;
	private javax.swing.JLabel jLabel103 = null;
	private javax.swing.JLabel jLabel104 = null;
	private javax.swing.JLabel jLabel105 = null;
	private javax.swing.JLabel jLabel106 = null;
	private javax.swing.JLabel jLabel107 = null;
	private javax.swing.JLabel jLabel108 = null;
	private javax.swing.JLabel jLabel109 = null;
	private javax.swing.JLabel jLabel110 = null;
	private javax.swing.JLabel jLabel111 = null;
	private javax.swing.JLabel jLabel112 = null;
	private javax.swing.JLabel jLabel113 = null;
	private javax.swing.JLabel jLabel114 = null;
	private javax.swing.JLabel jLabel115 = null;
	private javax.swing.JLabel jLabel116 = null;
	private javax.swing.JTextField jTextField78 = null;
	private javax.swing.JTextField jTextField79 = null;
	private javax.swing.JTextField jTextField80 = null;
	private javax.swing.JTextField jTextField81 = null;
	private javax.swing.JTextField jTextField82 = null;
	private javax.swing.JTextField jTextField83 = null;
	private javax.swing.JTextField jTextField84 = null;
	private javax.swing.JTextField jTextField85 = null;
	private javax.swing.JTextField jTextField86 = null;
	private javax.swing.JTextField jTextField87 = null;
	private javax.swing.JTextField jTextField88 = null;
	private javax.swing.JTextField jTextField89 = null;
	private javax.swing.JTextField jTextField90 = null;
	private javax.swing.JTextField jTextField91 = null;
	private javax.swing.JTextField jTextField92 = null;
	private javax.swing.JTextField jTextField93 = null;
	private javax.swing.JTextField jTextField94 = null;
	private javax.swing.JTextField jTextField95 = null;
	private javax.swing.JTextField jTextField96 = null;
	private javax.swing.JTextField jTextField97 = null;
	private javax.swing.JTextField jTextField98 = null;
	private javax.swing.JTextField jTextField99 = null;
	private javax.swing.JTextField jTextField100 = null;
	private javax.swing.JTextField jTextField101 = null;
	private javax.swing.JTextField jTextField102 = null;
	private javax.swing.JTextField jTextField103 = null;
	private javax.swing.JTextField jTextField104 = null;
	private javax.swing.JTextField jTextField105 = null;
	private javax.swing.JTextField jTextField106 = null;
	private javax.swing.JTextField jTextField107 = null;
	private javax.swing.JTextField jTextField108 = null;
	private javax.swing.JTextField jTextField109 = null;
	private javax.swing.JTextField jTextField110 = null;
	private javax.swing.JTextField jTextField111 = null;
	private javax.swing.JTextField jTextField112 = null;
	private javax.swing.JTextField jTextField113 = null;
	private javax.swing.JTextField jTextField114 = null;
	private javax.swing.JTextField jTextField115 = null;
	private javax.swing.JTextField jTextField116 = null;
	private javax.swing.JButton jButton6 = null;
	private javax.swing.JButton jButton7 = null;
	
	
	
	/**
	 * This is the default constructor
	 */
	public JHotel_Translator() {
		super();
		initialize();
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setLayout(null);
		this.add(getJPanel(), null);
		this.add(getJButton(), null);
		this.add(getJPanel1(), null);
		this.add(getJButton1(), null);
		this.add(getJButton2(), null);
		this.add(getJButton3(), null);
		this.add(getJPanel2(), null);
		this.add(getJButton4(), null);
		this.add(getJButton5(), null);
		this.add(getJPanel3(), null);
		this.add(getJButton6(), null);
		this.add(getJButton7(), null);
		this.setSize(941, 632);
		this.setVisible(true);
		this.setTitle("JHotel Translator");
		this.addWindowListener(new java.awt.event.WindowAdapter() { 
			public void windowClosing(java.awt.event.WindowEvent e) {    
				System.exit(0);
			}
		});
	}
	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJPanel() {
		if(jPanel == null) {
			jPanel = new javax.swing.JPanel();
			jPanel.setBounds(17, 90, 908, 502);
			
			jPanel.setLayout(null);
			jPanel.add(getJLabel(), null);
			jPanel.add(getJLabel1(), null);
			jPanel.add(getJLabel2(), null);
			jPanel.add(getJLabel3(), null);
			jPanel.add(getJLabel4(), null);
			jPanel.add(getJLabel5(), null);
			jPanel.add(getJLabel6(), null);
			jPanel.add(getJLabel7(), null);
			jPanel.add(getJLabel8(), null);
			jPanel.add(getJLabel9(), null);
			jPanel.add(getJLabel10(), null);
			jPanel.add(getJLabel11(), null);
			jPanel.add(getJLabel12(), null);
			jPanel.add(getJLabel13(), null);
			jPanel.add(getJLabel14(), null);
			jPanel.add(getJLabel15(), null);
			jPanel.add(getJLabel16(), null);
			jPanel.add(getJLabel17(), null);
			jPanel.add(getJLabel18(), null);
			jPanel.add(getJLabel19(), null);
			jPanel.add(getJLabel20(), null);
			jPanel.add(getJLabel21(), null);
			jPanel.add(getJLabel22(), null);
			jPanel.add(getJLabel23(), null);
			jPanel.add(getJLabel24(), null);
			jPanel.add(getJLabel25(), null);
			jPanel.add(getJTextField(), null);
			jPanel.add(getJTextField1(), null);
			jPanel.add(getJTextField2(), null);
			jPanel.add(getJTextField3(), null);
			jPanel.add(getJTextField4(), null);
			jPanel.add(getJTextField5(), null);
			jPanel.add(getJTextField6(), null);
			jPanel.add(getJTextField7(), null);
			jPanel.add(getJTextField8(), null);
			jPanel.add(getJTextField9(), null);
			jPanel.add(getJTextField10(), null);
			jPanel.add(getJTextField11(), null);
			jPanel.add(getJTextField12(), null);
			jPanel.add(getJTextField13(), null);
			jPanel.add(getJTextField14(), null);
			jPanel.add(getJTextField15(), null);
			jPanel.add(getJTextField16(), null);
			jPanel.add(getJTextField17(), null);
			jPanel.add(getJTextField18(), null);
			jPanel.add(getJTextField19(), null);
			jPanel.add(getJTextField20(), null);
			jPanel.add(getJTextField21(), null);
			jPanel.add(getJTextField22(), null);
			jPanel.add(getJTextField23(), null);
			jPanel.add(getJTextField24(), null);
			jPanel.add(getJTextField25(), null);
			jPanel.add(getJLabel26(), null);
			jPanel.add(getJLabel27(), null);
			jPanel.add(getJLabel28(), null);
			jPanel.add(getJLabel29(), null);
			jPanel.add(getJLabel30(), null);
			jPanel.add(getJLabel31(), null);
			jPanel.add(getJLabel32(), null);
			jPanel.add(getJLabel33(), null);
			jPanel.add(getJLabel34(), null);
			jPanel.add(getJLabel35(), null);
			jPanel.add(getJLabel36(), null);
			jPanel.add(getJLabel37(), null);
			jPanel.add(getJLabel38(), null);
			jPanel.add(getJTextField26(), null);
			jPanel.add(getJTextField27(), null);
			jPanel.add(getJTextField28(), null);
			jPanel.add(getJTextField29(), null);
			jPanel.add(getJTextField30(), null);
			jPanel.add(getJTextField31(), null);
			jPanel.add(getJTextField32(), null);
			jPanel.add(getJTextField33(), null);
			jPanel.add(getJTextField34(), null);
			jPanel.add(getJTextField35(), null);
			jPanel.add(getJTextField36(), null);
			jPanel.add(getJTextField37(), null);
			jPanel.add(getJTextField38(), null);

			jPanel.setBackground(java.awt.SystemColor.window);
			jPanel.setVisible(true);
			
			
		}
		return jPanel;
	}
	
	private javax.swing.JLabel getJLabel() {
		if(jLabel == null) {
			jLabel = new javax.swing.JLabel();
			jLabel.setBounds(20, 19, 91, 24);
			jLabel.setText("New");
		}
		return jLabel;
	}
	/**
	 * This method initializes jLabel1
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel1() {
		if(jLabel1 == null) {
			jLabel1 = new javax.swing.JLabel();
			jLabel1.setBounds(20, 54, 91, 24);
			jLabel1.setText("Search");
		}
		return jLabel1;
	}
	/**
	 * This method initializes jLabel2
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel2() {
		if(jLabel2 == null) {
			jLabel2 = new javax.swing.JLabel();
			jLabel2.setBounds(20, 89, 91, 24);
			jLabel2.setText("Save");
		}
		return jLabel2;
	}
	/**
	 * This method initializes jLabel3
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel3() {
		if(jLabel3 == null) {
			jLabel3 = new javax.swing.JLabel();
			jLabel3.setBounds(20, 124, 91, 24);
			jLabel3.setText("Export DB");
		}
		return jLabel3;
	}
	/**
	 * This method initializes jLabel4
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel4() {
		if(jLabel4 == null) {
			jLabel4 = new javax.swing.JLabel();
			jLabel4.setBounds(20, 159, 91, 24);
			jLabel4.setText("Import DB");
		}
		return jLabel4;
	}
	/**
	 * This method initializes jLabel5
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel5() {
		if(jLabel5 == null) {
			jLabel5 = new javax.swing.JLabel();
			jLabel5.setBounds(20, 194, 91, 24);
			jLabel5.setText("Options");
		}
		return jLabel5;
	}
	/**
	 * This method initializes jLabel6
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel6() {
		if(jLabel6 == null) {
			jLabel6 = new javax.swing.JLabel();
			jLabel6.setBounds(20, 229, 91, 24);
			jLabel6.setText("Preferences");
		}
		return jLabel6;
	}
	/**
	 * This method initializes jLabel7
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel7() {
		if(jLabel7 == null) {
			jLabel7 = new javax.swing.JLabel();
			jLabel7.setBounds(20, 264, 91, 24);
			jLabel7.setText("Spouse");
		}
		return jLabel7;
	}
	/**
	 * This method initializes jLabel8
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel8() {
		if(jLabel8 == null) {
			jLabel8 = new javax.swing.JLabel();
			jLabel8.setBounds(20, 299, 91, 24);
			jLabel8.setText("Children");
		}
		return jLabel8;
	}
	/**
	 * This method initializes jLabel9
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel9() {
		if(jLabel9 == null) {
			jLabel9 = new javax.swing.JLabel();
			jLabel9.setBounds(20, 334, 91, 24);
			jLabel9.setText("Phone-#");
		}
		return jLabel9;
	}
	/**
	 * This method initializes jLabel10
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel10() {
		if(jLabel10 == null) {
			jLabel10 = new javax.swing.JLabel();
			jLabel10.setBounds(20, 369, 91, 24);
			jLabel10.setText("Mobile-#");
		}
		return jLabel10;
	}
	/**
	 * This method initializes jLabel11
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel11() {
		if(jLabel11 == null) {
			jLabel11 = new javax.swing.JLabel();
			jLabel11.setBounds(20, 404, 91, 24);
			jLabel11.setText("Fax-#");
		}
		return jLabel11;
	}
	/**
	 * This method initializes jLabel12
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel12() {
		if(jLabel12 == null) {
			jLabel12 = new javax.swing.JLabel();
			jLabel12.setBounds(20, 439, 91, 24);
			jLabel12.setText("E-Mail");
		}
		return jLabel12;
	}
	/**
	 * This method initializes jLabel13
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel13() {
		if(jLabel13 == null) {
			jLabel13 = new javax.swing.JLabel();
			jLabel13.setBounds(316, 19, 91, 24);
			jLabel13.setText("Fav. room");
		}
		return jLabel13;
	}
	/**
	 * This method initializes jLabel14
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel14() {
		if(jLabel14 == null) {
			jLabel14 = new javax.swing.JLabel();
			jLabel14.setBounds(316, 54, 91, 24);
			jLabel14.setText("Smoker");
		}
		return jLabel14;
	}
	/**
	 * This method initializes jLabel15
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel15() {
		if(jLabel15 == null) {
			jLabel15 = new javax.swing.JLabel();
			jLabel15.setBounds(316, 89, 91, 24);
			jLabel15.setText("Yes");
		}
		return jLabel15;
	}
	/**
	 * This method initializes jLabel16
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel16() {
		if(jLabel16 == null) {
			jLabel16 = new javax.swing.JLabel();
			jLabel16.setBounds(316, 124, 91, 24);
			jLabel16.setText("No");
		}
		return jLabel16;
	}
	
	/**
	 * This method initializes jLabel17
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel17() {
		if(jLabel17 == null) {
			jLabel17 = new javax.swing.JLabel();
			jLabel17.setBounds(316, 159, 91, 24);
			jLabel17.setText("Private");
		}
		return jLabel17;
	}
	/**
	 * This method initializes jLabel18
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel18() {
		if(jLabel18 == null) {
			jLabel18 = new javax.swing.JLabel();
			jLabel18.setBounds(316, 194, 91, 24);
			jLabel18.setText("Business");
		}
		return jLabel18;
	}
	/**
	 * This method initializes jLabel19
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel19() {
		if(jLabel19 == null) {
			jLabel19 = new javax.swing.JLabel();
			jLabel19.setBounds(316, 229, 91, 24);
			jLabel19.setText("New File");
		}
		return jLabel19;
	}
	/**
	 * This method initializes jLabel20
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel20() {
		if(jLabel20 == null) {
			jLabel20 = new javax.swing.JLabel();
			jLabel20.setBounds(316, 264, 91, 24);
			jLabel20.setText("Load");
		}
		return jLabel20;
	}
	/**
	 * This method initializes jLabel21
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel21() {
		if(jLabel21 == null) {
			jLabel21 = new javax.swing.JLabel();
			jLabel21.setBounds(316, 299, 91, 24);
			jLabel21.setText("OK");
		}
		return jLabel21;
	}
	/**
	 * This method initializes jLabel22
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel22() {
		if(jLabel22 == null) {
			jLabel22 = new javax.swing.JLabel();
			jLabel22.setBounds(316, 334, 91, 24);
			jLabel22.setText("Cancel");
		}
		return jLabel22;
	}
	/**
	 * This method initializes jLabel23
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel23() {
		if(jLabel23 == null) {
			jLabel23 = new javax.swing.JLabel();
			jLabel23.setBounds(316, 369, 91, 24);
			jLabel23.setText("Browse");
		}
		return jLabel23;
	}
	/**
	 * This method initializes jLabel24
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel24() {
		if(jLabel24 == null) {
			jLabel24 = new javax.swing.JLabel();
			jLabel24.setBounds(316, 404, 91, 24);
			jLabel24.setText("Quit");
		}
		return jLabel24;
	}
	/**
	 * This method initializes jLabel25
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel25() {
		if(jLabel25 == null) {
			jLabel25 = new javax.swing.JLabel();
			jLabel25.setBounds(316, 439, 91, 24);
			jLabel25.setText("Show");
		}
		return jLabel25;
	}
	/**
	 * This method initializes jTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField() {
		if(jTextField == null) {
			jTextField = new javax.swing.JTextField();
			jTextField.setNextFocusableComponent(getJTextField1());
			jTextField.setBounds(117, 19, 177, 24);
		}
		return jTextField;
	}
	/**
	 * This method initializes jTextField1
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField1() {
		if(jTextField1 == null) {
			jTextField1 = new javax.swing.JTextField();
			jTextField1.setNextFocusableComponent(getJTextField2());
			jTextField1.setBounds(117, 54, 177, 24);
		}
		return jTextField1;
	}
	/**
	 * This method initializes jTextField2
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField2() {
		if(jTextField2 == null) {
			jTextField2 = new javax.swing.JTextField();
			jTextField2.setNextFocusableComponent(getJTextField3());
			jTextField2.setBounds(117, 89, 177, 24);
		}
		return jTextField2;
	}
	/**
	 * This method initializes jTextField3
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField3() {
		if(jTextField3 == null) {
			jTextField3 = new javax.swing.JTextField();
			jTextField3.setNextFocusableComponent(getJTextField4());
			jTextField3.setBounds(117, 124, 177, 24);
		}
		return jTextField3;
	}
	/**
	 * This method initializes jTextField4
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField4() {
		if(jTextField4 == null) {
			jTextField4 = new javax.swing.JTextField();
			jTextField4.setNextFocusableComponent(getJTextField5());
			jTextField4.setBounds(117, 159, 177, 24);
		}
		return jTextField4;
	}
	/**
	 * This method initializes jTextField5
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField5() {
		if(jTextField5 == null) {
			jTextField5 = new javax.swing.JTextField();
			jTextField5.setNextFocusableComponent(getJTextField6());
			jTextField5.setBounds(117, 194, 177, 24);
		}
		return jTextField5;
	}
	/**
	 * This method initializes jTextField6
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField6() {
		if(jTextField6 == null) {
			jTextField6 = new javax.swing.JTextField();
			jTextField6.setNextFocusableComponent(getJTextField7());
			jTextField6.setBounds(117, 229, 177, 24);
		}
		return jTextField6;
	}
	/**
	 * This method initializes jTextField7
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField7() {
		if(jTextField7 == null) {
			jTextField7 = new javax.swing.JTextField();
			jTextField7.setNextFocusableComponent(getJTextField8());
			jTextField7.setBounds(117, 264, 177, 24);
		}
		return jTextField7;
	}
	/**
	 * This method initializes jTextField8
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField8() {
		if(jTextField8 == null) {
			jTextField8 = new javax.swing.JTextField();
			jTextField8.setNextFocusableComponent(getJTextField9());
			jTextField8.setBounds(117, 299, 177, 24);
		}
		return jTextField8;
	}
	/**
	 * This method initializes jTextField9
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField9() {
		if(jTextField9 == null) {
			jTextField9 = new javax.swing.JTextField();
			jTextField9.setNextFocusableComponent(getJTextField10());
			jTextField9.setBounds(117, 334, 177, 24);
		}
		return jTextField9;
	}
	/**
	 * This method initializes jTextField10
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField10() {
		if(jTextField10 == null) {
			jTextField10 = new javax.swing.JTextField();
			jTextField10.setNextFocusableComponent(getJTextField11());
			jTextField10.setBounds(117, 369, 177, 24);
		}
		return jTextField10;
	}
	/**
	 * This method initializes jTextField11
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField11() {
		if(jTextField11 == null) {
			jTextField11 = new javax.swing.JTextField();
			jTextField11.setNextFocusableComponent(getJTextField12());
			jTextField11.setBounds(117, 404, 177, 24);
		}
		return jTextField11;
	}
	/**
	 * This method initializes jTextField12
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField12() {
		if(jTextField12 == null) {
			jTextField12 = new javax.swing.JTextField();
			jTextField12.setNextFocusableComponent(getJTextField13());
			jTextField12.setBounds(117, 439, 177, 24);
		}
		return jTextField12;
	}
	/**
	 * This method initializes jTextField13
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField13() {
		if(jTextField13 == null) {
			jTextField13 = new javax.swing.JTextField();
			jTextField13.setNextFocusableComponent(getJTextField14());
			jTextField13.setBounds(413, 19, 177, 24);
		}
		return jTextField13;
	}
	/**
	 * This method initializes jTextField14
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField14() {
		if(jTextField14 == null) {
			jTextField14 = new javax.swing.JTextField();
			jTextField14.setNextFocusableComponent(getJTextField15());
			jTextField14.setBounds(413, 54, 177, 24);
		}
		return jTextField14;
	}
	/**
	 * This method initializes jTextField15
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField15() {
		if(jTextField15 == null) {
			jTextField15 = new javax.swing.JTextField();
			jTextField15.setNextFocusableComponent(getJTextField16());
			jTextField15.setBounds(413, 89, 177, 24);
		}
		return jTextField15;
	}
	/**
	 * This method initializes jTextField16
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField16() {
		if(jTextField16 == null) {
			jTextField16 = new javax.swing.JTextField();
			jTextField16.setNextFocusableComponent(getJTextField17());
			jTextField16.setBounds(413, 124, 177, 24);
		}
		return jTextField16;
	}
	/**
	 * This method initializes jTextField17
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField17() {
		if(jTextField17 == null) {
			jTextField17 = new javax.swing.JTextField();
			jTextField17.setNextFocusableComponent(getJTextField18());
			jTextField17.setBounds(413, 159, 177, 24);
		}
		return jTextField17;
	}
	/**
	 * This method initializes jTextField18
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField18() {
		if(jTextField18 == null) {
			jTextField18 = new javax.swing.JTextField();
			jTextField18.setNextFocusableComponent(getJTextField19());
			jTextField18.setBounds(413, 194, 177, 24);
		}
		return jTextField18;
	}
	/**
	 * This method initializes jTextField19
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField19() {
		if(jTextField19 == null) {
			jTextField19 = new javax.swing.JTextField();
			jTextField19.setNextFocusableComponent(getJTextField20());
			jTextField19.setBounds(413, 229, 177, 24);
		}
		return jTextField19;
	}
	/**
	 * This method initializes jTextField20
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField20() {
		if(jTextField20 == null) {
			jTextField20 = new javax.swing.JTextField();
			jTextField20.setNextFocusableComponent(getJTextField21());
			jTextField20.setBounds(413, 264, 177, 24);
		}
		return jTextField20;
	}
	/**
	 * This method initializes jTextField21
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField21() {
		if(jTextField21 == null) {
			jTextField21 = new javax.swing.JTextField();
			jTextField21.setNextFocusableComponent(getJTextField22());
			jTextField21.setBounds(413, 299, 177, 24);
		}
		return jTextField21;
	}
	/**
	 * This method initializes jTextField22
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField22() {
		if(jTextField22 == null) {
			jTextField22 = new javax.swing.JTextField();
			jTextField22.setNextFocusableComponent(getJTextField23());
			jTextField22.setBounds(413, 334, 177, 24);
		}
		return jTextField22;
	}
	/**
	 * This method initializes jTextField23
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField23() {
		if(jTextField23 == null) {
			jTextField23 = new javax.swing.JTextField();
			jTextField23.setNextFocusableComponent(getJTextField24());
			jTextField23.setBounds(413, 369, 177, 24);
		}
		return jTextField23;
	}
	/**
	 * This method initializes jTextField24
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField24() {
		if(jTextField24 == null) {
			jTextField24 = new javax.swing.JTextField();
			jTextField24.setNextFocusableComponent(getJTextField25());
			jTextField24.setBounds(413, 404, 177, 24);
		}
		return jTextField24;
	}
	/**
	 * This method initializes jTextField25
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField25() {
		if(jTextField25 == null) {
			jTextField25 = new javax.swing.JTextField();
			jTextField25.setNextFocusableComponent(getJTextField26());
			jTextField25.setBounds(413, 439, 177, 24);
		}
		return jTextField25;
	}
	/**
	 * This method initializes jLabel26
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel26() {
		if(jLabel26 == null) {
			jLabel26 = new javax.swing.JLabel();
			jLabel26.setBounds(610, 19, 91, 24);
			jLabel26.setText("Quicksearch");
		}
		return jLabel26;
	}
	/**
	 * This method initializes jLabel27
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel27() {
		if(jLabel27 == null) {
			jLabel27 = new javax.swing.JLabel();
			jLabel27.setBounds(610, 54, 91, 24);
			jLabel27.setText("Company");
		}
		return jLabel27;
	}
	/**
	 * This method initializes jLabel28
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel28() {
		if(jLabel28 == null) {
			jLabel28 = new javax.swing.JLabel();
			jLabel28.setBounds(610, 89, 91, 24);
			jLabel28.setText("First name");
		}
		return jLabel28;
	}
	/**
	 * This method initializes jLabel29
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel29() {
		if(jLabel29 == null) {
			jLabel29 = new javax.swing.JLabel();
			jLabel29.setBounds(610, 124, 91, 24);
			jLabel29.setText("Last name");
		}
		return jLabel29;
	}
	/**
	 * This method initializes jLabel30
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel30() {
		if(jLabel30 == null) {
			jLabel30 = new javax.swing.JLabel();
			jLabel30.setBounds(610, 159, 91, 24);
			jLabel30.setText("Address");
		}
		return jLabel30;
	}
	/**
	 * This method initializes jLabel31
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel31() {
		if(jLabel31 == null) {
			jLabel31 = new javax.swing.JLabel();
			jLabel31.setBounds(610, 194, 91, 24);
			jLabel31.setText("Citizenship");
		}
		return jLabel31;
	}
	/**
	 * This method initializes jLabel32
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel32() {
		if(jLabel32 == null) {
			jLabel32 = new javax.swing.JLabel();
			jLabel32.setBounds(610, 229, 91, 24);
			jLabel32.setText("Add. Data");
		}
		return jLabel32;
	}
	/**
	 * This method initializes jLabel33
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel33() {
		if(jLabel33 == null) {
			jLabel33 = new javax.swing.JLabel();
			jLabel33.setBounds(610, 264, 91, 24);
			jLabel33.setText("Delete");
		}
		return jLabel33;
	}
	/**
	 * This method initializes jLabel34
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel34() {
		if(jLabel34 == null) {
			jLabel34 = new javax.swing.JLabel();
			jLabel34.setBounds(610, 299, 91, 24);
			jLabel34.setText("Clear Fields");
		}
		return jLabel34;
	}
	/**
	 * This method initializes jLabel35
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel35() {
		if(jLabel35 == null) {
			jLabel35 = new javax.swing.JLabel();
			jLabel35.setBounds(610, 334, 91, 24);
			jLabel35.setText("Database");
		}
		return jLabel35;
	}
	/**
	 * This method initializes jLabel36
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel36() {
		if(jLabel36 == null) {
			jLabel36 = new javax.swing.JLabel();
			jLabel36.setBounds(610, 369, 91, 24);
			jLabel36.setText("Language");
		}
		return jLabel36;
	}
	/**
	 * This method initializes jLabel37
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel37() {
		if(jLabel37 == null) {
			jLabel37 = new javax.swing.JLabel();
			jLabel37.setBounds(610, 404, 91, 24);
			jLabel37.setText("Standard");
		}
		return jLabel37;
	}
	/**
	 * This method initializes jLabel38
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel38() {
		if(jLabel38 == null) {
			jLabel38 = new javax.swing.JLabel();
			jLabel38.setBounds(610, 439, 91, 24);
			jLabel38.setText("Other");
		}
		return jLabel38;
	}
	/**
	 * This method initializes jTextField26
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField26() {
		if(jTextField26 == null) {
			jTextField26 = new javax.swing.JTextField();
			jTextField26.setNextFocusableComponent(getJTextField27());
			jTextField26.setBounds(708, 19, 177, 24);
		}
		return jTextField26;
	}
	/**
	 * This method initializes jTextField27
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField27() {
		if(jTextField27 == null) {
			jTextField27 = new javax.swing.JTextField();
			jTextField27.setNextFocusableComponent(getJTextField28());
			jTextField27.setBounds(708, 54, 177, 24);
		}
		return jTextField27;
	}
	/**
	 * This method initializes jTextField28
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField28() {
		if(jTextField28 == null) {
			jTextField28 = new javax.swing.JTextField();
			jTextField28.setNextFocusableComponent(getJTextField29());
			jTextField28.setBounds(708, 89, 177, 24);
		}
		return jTextField28;
	}
	/**
	 * This method initializes jTextField29
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField29() {
		if(jTextField29 == null) {
			jTextField29 = new javax.swing.JTextField();
			jTextField29.setNextFocusableComponent(getJTextField30());
			jTextField29.setBounds(708, 124, 177, 24);
		}
		return jTextField29;
	}
	/**
	 * This method initializes jTextField30
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField30() {
		if(jTextField30 == null) {
			jTextField30 = new javax.swing.JTextField();
			jTextField30.setNextFocusableComponent(getJTextField31());
			jTextField30.setBounds(708, 159, 177, 24);
		}
		return jTextField30;
	}
	/**
	 * This method initializes jTextField31
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField31() {
		if(jTextField31 == null) {
			jTextField31 = new javax.swing.JTextField();
			jTextField31.setNextFocusableComponent(getJTextField32());
			jTextField31.setBounds(708, 194, 177, 24);
		}
		return jTextField31;
	}
	/**
	 * This method initializes jTextField32
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField32() {
		if(jTextField32 == null) {
			jTextField32 = new javax.swing.JTextField();
			jTextField32.setNextFocusableComponent(getJTextField33());
			jTextField32.setBounds(708, 229, 177, 24);
		}
		return jTextField32;
	}
	/**
	 * This method initializes jTextField33
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField33() {
		if(jTextField33 == null) {
			jTextField33 = new javax.swing.JTextField();
			jTextField33.setNextFocusableComponent(getJTextField34());
			jTextField33.setBounds(708, 264, 177, 24);
		}
		return jTextField33;
	}
	/**
	 * This method initializes jTextField34
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField34() {
		if(jTextField34 == null) {
			jTextField34 = new javax.swing.JTextField();
			jTextField34.setNextFocusableComponent(getJTextField35());
			jTextField34.setBounds(708, 299, 177, 24);
		}
		return jTextField34;
	}
	/**
	 * This method initializes jTextField35
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField35() {
		if(jTextField35 == null) {
			jTextField35 = new javax.swing.JTextField();
			jTextField35.setNextFocusableComponent(getJTextField36());
			jTextField35.setBounds(708, 334, 177, 24);
		}
		return jTextField35;
	}
	/**
	 * This method initializes jTextField36
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField36() {
		if(jTextField36 == null) {
			jTextField36 = new javax.swing.JTextField();
			jTextField36.setNextFocusableComponent(getJTextField37());
			jTextField36.setBounds(708, 369, 177, 24);
		}
		return jTextField36;
	}
	/**
	 * This method initializes jTextField37
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField37() {
		if(jTextField37 == null) {
			jTextField37 = new javax.swing.JTextField();
			jTextField37.setNextFocusableComponent(getJTextField38());
			jTextField37.setBounds(708, 404, 177, 24);
		}
		return jTextField37;
	}
	/**
	 * This method initializes jTextField38
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField38() {
		if(jTextField38 == null) {
			jTextField38 = new javax.swing.JTextField();
			jTextField38.setNextFocusableComponent(getJButton());
			jTextField38.setBounds(708, 439, 177, 24);
		}
		return jTextField38;
	}

	
	
	
	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton() {
		if(jButton == null) {
			jButton = new javax.swing.JButton();
			jButton.setBounds(784, 598, 141, 23);
			jButton.setText("Next");
			jButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					jPanel.setVisible(false);
					jPanel1.setVisible(true);
					jPanel2.setVisible(false);
					jPanel3.setVisible(false);
					jButton.setVisible(false);
					jButton1.setVisible(false);
					jButton4.setVisible(true);
					jButton2.setVisible(true);
					jButton3.setVisible(false);
					jButton5.setVisible(false);
					jButton6.setVisible(false);
					jButton7.setVisible(false);
				}
			});
		}
		return jButton;
	}
	/**
	 * This method initializes jPanel1
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJPanel1() {
		if(jPanel1 == null) {
			jPanel1 = new javax.swing.JPanel();
			jPanel1.setLayout(null);
			jPanel1.add(getJLabel39(), null);
			jPanel1.add(getJLabel40(), null);
			jPanel1.add(getJLabel41(), null);
			jPanel1.add(getJLabel42(), null);
			jPanel1.add(getJLabel43(), null);
			jPanel1.add(getJLabel44(), null);
			jPanel1.add(getJLabel45(), null);
			jPanel1.add(getJLabel46(), null);
			jPanel1.add(getJLabel47(), null);
			jPanel1.add(getJLabel48(), null);
			jPanel1.add(getJLabel49(), null);
			jPanel1.add(getJLabel50(), null);
			jPanel1.add(getJLabel51(), null);
			jPanel1.add(getJTextField39(), null);
			jPanel1.add(getJTextField40(), null);
			jPanel1.add(getJTextField41(), null);
			jPanel1.add(getJTextField42(), null);
			jPanel1.add(getJTextField43(), null);
			jPanel1.add(getJTextField44(), null);
			jPanel1.add(getJTextField45(), null);
			jPanel1.add(getJTextField46(), null);
			jPanel1.add(getJTextField47(), null);
			jPanel1.add(getJTextField48(), null);
			jPanel1.add(getJTextField49(), null);
			jPanel1.add(getJTextField50(), null);
			jPanel1.add(getJTextField51(), null);
			jPanel1.add(getJTextArea(), null);
			jPanel1.add(getJTextArea1(), null);
			jPanel1.add(getJTextArea2(), null);
			jPanel1.add(getJTextArea3(), null);
			jPanel1.setBounds(17, 90, 908, 502);
			jPanel1.setBackground(java.awt.SystemColor.window);
			jPanel1.setVisible(false);
		}
		return jPanel1;
	}
	/**
	 * This method initializes jLabel39
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel39() {
		if(jLabel39 == null) {
			jLabel39 = new javax.swing.JLabel();
			jLabel39.setBounds(20, 19, 182, 24);
			jLabel39.setText("Choose language");
		}
		return jLabel39;
	}
	/**
	 * This method initializes jLabel40
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel40() {
		if(jLabel40 == null) {
			jLabel40 = new javax.swing.JLabel();
			jLabel40.setBounds(20, 54, 182, 24);
			jLabel40.setText("Search criterion");
		}
		return jLabel40;
	}
	/**
	 * This method initializes jLabel41
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel41() {
		if(jLabel41 == null) {
			jLabel41 = new javax.swing.JLabel();
			jLabel41.setBounds(20, 88, 182, 25);
			jLabel41.setText("Back");
		}
		return jLabel41;
	}
	/**
	 * This method initializes jLabel42
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel42() {
		if(jLabel42 == null) {
			jLabel42 = new javax.swing.JLabel();
			jLabel42.setBounds(20, 124, 182, 23);
			jLabel42.setText("File");
		}
		return jLabel42;
	}
	/**
	 * This method initializes jLabel43
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel43() {
		if(jLabel43 == null) {
			jLabel43 = new javax.swing.JLabel();
			jLabel43.setBounds(20, 159, 182, 24);
			jLabel43.setText("Reservation Management");
		}
		return jLabel43;
	}
	/**
	 * This method initializes jLabel44
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel44() {
		if(jLabel44 == null) {
			jLabel44 = new javax.swing.JLabel();
			jLabel44.setBounds(20, 194, 182, 24);
			jLabel44.setText("Room");
		}
		return jLabel44;
	}
	/**
	 * This method initializes jLabel45
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel45() {
		if(jLabel45 == null) {
			jLabel45 = new javax.swing.JLabel();
			jLabel45.setBounds(20, 229, 182, 24);
			jLabel45.setText("Birthday");
		}
		return jLabel45;
	}
	/**
	 * This method initializes jLabel46
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel46() {
		if(jLabel46 == null) {
			jLabel46 = new javax.swing.JLabel();
			jLabel46.setBounds(20, 264, 182, 24);
			jLabel46.setText("Not available yet");
		}
		return jLabel46;
	}
	/**
	 * This method initializes jLabel47
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel47() {
		if(jLabel47 == null) {
			jLabel47 = new javax.swing.JLabel();
			jLabel47.setBounds(20, 299, 182, 24);
			jLabel47.setText("Show");
		}
		return jLabel47;
	}
	/**
	 * This method initializes jLabel48
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel48() {
		if(jLabel48 == null) {
			jLabel48 = new javax.swing.JLabel();
			jLabel48.setBounds(20, 334, 182, 24);
			jLabel48.setText("Warning");
		}
		return jLabel48;
	}
	/**
	 * This method initializes jLabel49
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel49() {
		if(jLabel49 == null) {
			jLabel49 = new javax.swing.JLabel();
			jLabel49.setBounds(20, 369, 182, 24);
			jLabel49.setText("List all guests");
		}
		return jLabel49;
	}
	/**
	 * This method initializes jLabel50
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel50() {
		if(jLabel50 == null) {
			jLabel50 = new javax.swing.JLabel();
			jLabel50.setBounds(20, 404, 182, 24);
			jLabel50.setText("Guest management");
		}
		return jLabel50;
	}
	/**
	 * This method initializes jLabel51
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel51() {
		if(jLabel51 == null) {
			jLabel51 = new javax.swing.JLabel();
			jLabel51.setBounds(20, 439, 182, 24);
			jLabel51.setText("Floors");
		}
		return jLabel51;
	}
	/**
	 * This method initializes jTextField39
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField39() {
		if(jTextField39 == null) {
			jTextField39 = new javax.swing.JTextField();
			jTextField39.setNextFocusableComponent(getJTextField40());
			jTextField39.setBounds(208, 19, 238, 24);
		}
		return jTextField39;
	}
	/**
	 * This method initializes jTextField40
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField40() {
		if(jTextField40 == null) {
			jTextField40 = new javax.swing.JTextField();
			jTextField40.setNextFocusableComponent(getJTextField41());
			jTextField40.setBounds(208, 54, 238, 24);
		}
		return jTextField40;
	}
	/**
	 * This method initializes jTextField41
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField41() {
		if(jTextField41 == null) {
			jTextField41 = new javax.swing.JTextField();
			jTextField41.setNextFocusableComponent(getJTextField42());
			jTextField41.setBounds(208, 89, 238, 24);
		}
		return jTextField41;
	}
	/**
	 * This method initializes jTextField42
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField42() {
		if(jTextField42 == null) {
			jTextField42 = new javax.swing.JTextField();
			jTextField42.setNextFocusableComponent(getJTextField43());
			jTextField42.setBounds(208, 124, 238, 24);
		}
		return jTextField42;
	}
	/**
	 * This method initializes jTextField43
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField43() {
		if(jTextField43 == null) {
			jTextField43 = new javax.swing.JTextField();
			jTextField43.setNextFocusableComponent(getJTextField44());
			jTextField43.setBounds(208, 159, 238, 24);
		}
		return jTextField43;
	}
	/**
	 * This method initializes jTextField44
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField44() {
		if(jTextField44 == null) {
			jTextField44 = new javax.swing.JTextField();
			jTextField44.setNextFocusableComponent(getJTextField45());
			jTextField44.setBounds(208, 194, 238, 24);
		}
		return jTextField44;
	}
	/**
	 * This method initializes jTextField45
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField45() {
		if(jTextField45 == null) {
			jTextField45 = new javax.swing.JTextField();
			jTextField45.setNextFocusableComponent(getJTextField46());
			jTextField45.setBounds(208, 229, 238, 24);
		}
		return jTextField45;
	}
	/**
	 * This method initializes jTextField46
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField46() {
		if(jTextField46 == null) {
			jTextField46 = new javax.swing.JTextField();
			jTextField46.setNextFocusableComponent(getJTextField47());
			jTextField46.setBounds(208, 264, 238, 24);
		}
		return jTextField46;
	}
	/**
	 * This method initializes jTextField47
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField47() {
		if(jTextField47 == null) {
			jTextField47 = new javax.swing.JTextField();
			jTextField47.setNextFocusableComponent(getJTextField48());
			jTextField47.setBounds(208, 299, 238, 24);
		}
		return jTextField47;
	}
	/**
	 * This method initializes jTextField48
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField48() {
		if(jTextField48 == null) {
			jTextField48 = new javax.swing.JTextField();
			jTextField48.setNextFocusableComponent(getJTextField49());
			jTextField48.setBounds(208, 334, 238, 24);
		}
		return jTextField48;
	}
	/**
	 * This method initializes jTextField49
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField49() {
		if(jTextField49 == null) {
			jTextField49 = new javax.swing.JTextField();
			jTextField49.setNextFocusableComponent(getJTextField50());
			jTextField49.setBounds(208, 369, 238, 24);
		}
		return jTextField49;
	}
	/**
	 * This method initializes jTextField50
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField50() {
		if(jTextField50 == null) {
			jTextField50 = new javax.swing.JTextField();
			jTextField50.setNextFocusableComponent(getJTextField51());
			jTextField50.setBounds(208, 404, 238, 24);
		}
		return jTextField50;
	}
	/**
	 * This method initializes jTextField51
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField51() {
		if(jTextField51 == null) {
			jTextField51 = new javax.swing.JTextField();
			jTextField51.setNextFocusableComponent(getJTextArea1());
			jTextField51.setBounds(208, 439, 238, 24);
		}
		return jTextField51;
	}
	/**
	 * This method initializes jButton1
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton1() {
		if(jButton1 == null) {
			jButton1 = new javax.swing.JButton();
			jButton1.setBounds(681, 598, 244, 23);
			jButton1.setText("Finish and create Language-File");
			jButton1.setVisible(false);
			jButton1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					writeLanguageFile();
					clearFields();
				}
			});
		}
		return jButton1;
	}
	/**
	 * This method initializes jButton2
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton2() {
		if(jButton2 == null) {
			jButton2 = new javax.swing.JButton();
			jButton2.setBounds(17, 598, 141, 23);
			jButton2.setText("Back");
			jButton2.setVisible(false);
			jButton2.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					jPanel1.setVisible(false);
					jPanel.setVisible(true);
					jButton1.setVisible(false);
					jButton2.setVisible(false);
					jButton3.setVisible(true);
					jButton.setVisible(true);
				}
			});
		}
		return jButton2;
	}
	
	public static void main(String[] args) {
		JHotel_Translator jht = new JHotel_Translator();
		
	}
	/**
	 * This method initializes jTextArea
	 * 
	 * @return javax.swing.JTextArea
	 */
	private javax.swing.JTextArea getJTextArea() {
		if(jTextArea == null) {
			jTextArea = new javax.swing.JTextArea();
			jTextArea.setBounds(484, 19, 270, 58);
			jTextArea.setBackground(java.awt.SystemColor.window);
			jTextArea.setWrapStyleWord(true);
			jTextArea.setLineWrap(true);
			jTextArea.setText("The current guest was modified - are you sure, you want to discard the changes?");
			jTextArea.setEditable(false);
			jTextArea.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 12));
		}
		return jTextArea;
	}
	/**
	 * This method initializes jTextArea1
	 * 
	 * @return javax.swing.JTextArea
	 */
	private javax.swing.JTextArea getJTextArea1() {
		if(jTextArea1 == null) {
			jTextArea1 = new javax.swing.JTextArea();
			jTextArea1.setBounds(484, 78, 270, 72);
			jTextArea1.setLineWrap(true);
			jTextArea1.setWrapStyleWord(true);
		}
		return jTextArea1;
	}
	/**
	 * This method initializes jTextArea2
	 * 
	 * @return javax.swing.JTextArea
	 */
	private javax.swing.JTextArea getJTextArea2() {
		if(jTextArea2 == null) {
			jTextArea2 = new javax.swing.JTextArea();
			jTextArea2.setBounds(484, 201, 270, 58);
			jTextArea2.setBackground(java.awt.SystemColor.window);
			jTextArea2.setWrapStyleWord(true);
			jTextArea2.setLineWrap(true);
			jTextArea2.setText("You're about to delete the current guest - are you sure?");
			jTextArea2.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 12));
		}
		return jTextArea2;
	}
	/**
	 * This method initializes jTextArea3
	 * 
	 * @return javax.swing.JTextArea
	 */
	private javax.swing.JTextArea getJTextArea3() {
		if(jTextArea3 == null) {
			jTextArea3 = new javax.swing.JTextArea();
			jTextArea3.setBounds(484, 258, 270, 72);
			jTextArea3.setWrapStyleWord(true);
			jTextArea3.setLineWrap(true);
			jTextArea3.setBackground(java.awt.Color.white);
		}
		return jTextArea3;
	}

	public void writeLanguageFile() {
		String[] langfile = new String[count];
		String filename = "";
		
		
		JFileChooser chooser = new JFileChooser("./cfg");
		int returnVal = chooser.showSaveDialog(JHotel_Translator.this);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			filename = (chooser.getSelectedFile().getPath());
		}

		
		
		
		langfile[0] = jTextField.getText();
		langfile[1] = jTextField1.getText();
		langfile[2] = jTextField2.getText();
		langfile[3] = jTextField3.getText();
		langfile[4] = jTextField4.getText();
		langfile[5] = jTextField5.getText();
		langfile[6] = jTextField6.getText();
		langfile[7] = jTextField7.getText();
		langfile[8] = jTextField8.getText();
		langfile[9] = jTextField9.getText();
		langfile[10] = jTextField10.getText();
		langfile[11] = jTextField11.getText();
		langfile[12] = jTextField12.getText();
		langfile[13] = jTextField13.getText();
		langfile[14] = jTextField14.getText();
		langfile[15] = jTextField15.getText();
		langfile[16] = jTextField16.getText();
		langfile[17] = jTextField17.getText();
		langfile[18] = jTextField18.getText();
		langfile[19] = jTextField19.getText();
		langfile[20] = jTextField20.getText();
		langfile[21] = jTextField21.getText();
		langfile[22] = jTextField22.getText();
		langfile[23] = jTextField23.getText();
		langfile[24] = jTextField24.getText();
		langfile[25] = jTextField25.getText();
		langfile[26] = jTextField26.getText();
		langfile[27] = jTextField27.getText();
		langfile[28] = jTextField28.getText();
		langfile[29] = jTextField29.getText();
		langfile[30] = jTextField30.getText();
		langfile[31] = jTextField31.getText();
		langfile[32] = jTextField32.getText();
		langfile[33] = jTextField33.getText();
		langfile[34] = jTextField34.getText();
		langfile[35] = jTextField35.getText();
		langfile[36] = jTextField36.getText();
		langfile[37] = jTextField37.getText();
		langfile[38] = jTextField38.getText();
		langfile[39] = jTextField39.getText();
		langfile[40] = jTextField40.getText();
		langfile[41] = jTextField41.getText();
		langfile[42] = jTextField42.getText();
		langfile[43] = jTextField43.getText();
		langfile[44] = jTextField44.getText();
		langfile[45] = jTextField45.getText();
		langfile[46] = jTextField46.getText();
		langfile[47] = jTextField47.getText();
		langfile[48] = jTextField48.getText();
		langfile[49] = jTextField49.getText();
		langfile[50] = jTextField50.getText();
		langfile[51] = jTextField51.getText();
		langfile[52] = jTextArea1.getText();
		langfile[53] = jTextArea3.getText();
		langfile[54] = jTextField52.getText();
		langfile[55] = jTextField53.getText();
		langfile[56] = jTextField54.getText();
		langfile[57] = jTextField55.getText();
		langfile[58] = jTextField56.getText();
		langfile[59] = jTextField57.getText();
		langfile[60] = jTextField58.getText();
		langfile[61] = jTextField59.getText();
		langfile[62] = jTextField60.getText();
		langfile[63] = jTextField61.getText();
		langfile[64] = jTextField62.getText();
		langfile[65] = jTextField63.getText();
		langfile[66] = jTextField64.getText();
		langfile[67] = jTextField65.getText();
		langfile[68] = jTextField66.getText();
		langfile[69] = jTextField67.getText();
		langfile[70] = jTextField68.getText();
		langfile[71] = jTextField69.getText();
		langfile[72] = jTextField70.getText();
		langfile[73] = jTextField71.getText();
		langfile[74] = jTextField72.getText();
		langfile[75] = jTextField73.getText();
		langfile[76] = jTextField74.getText();
		langfile[77] = jTextField75.getText();
		langfile[78] = jTextField76.getText();
		langfile[79] = jTextField77.getText();
		langfile[80] = jTextField78.getText();
		langfile[81] = jTextField79.getText();
		langfile[82] = jTextField80.getText();
		langfile[83] = jTextField81.getText();
		langfile[84] = jTextField82.getText();
		langfile[85] = jTextField83.getText();
		langfile[86] = jTextField84.getText();
		langfile[87] = jTextField85.getText();
		langfile[88] = jTextField86.getText();
		langfile[89] = jTextField87.getText();
		langfile[90] = jTextField88.getText();
		langfile[91] = jTextField89.getText();
		langfile[92] = jTextField90.getText();
		langfile[93] = jTextField91.getText();
		langfile[94] = jTextField92.getText();
		langfile[95] = jTextField93.getText();
		langfile[96] = jTextField94.getText();
		langfile[97] = jTextField95.getText();
		langfile[98] = jTextField96.getText();
		langfile[99] = jTextField97.getText();
		langfile[100] = jTextField98.getText();
		langfile[101] = jTextField99.getText();
		langfile[102] = jTextField100.getText();
		langfile[103] = jTextField101.getText();
		langfile[104] = jTextField102.getText();
		langfile[105] = jTextField103.getText();
		langfile[106] = jTextField104.getText();
		langfile[107] = jTextField105.getText();
		langfile[108] = jTextField106.getText();
		langfile[109] = jTextField107.getText();
		langfile[110] = jTextField108.getText();
		langfile[111] = jTextField109.getText();
		langfile[112] = jTextField110.getText();
		langfile[113] = jTextField111.getText();
		langfile[114] = jTextField112.getText();
		langfile[115] = jTextField113.getText();
		langfile[116] = jTextField114.getText();
		langfile[117] = jTextField115.getText();
		langfile[118] = jTextField116.getText();

		

		try {
			FileOutputStream fos = new FileOutputStream(filename);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			oos.writeObject(langfile);
			oos.flush();
			oos.close();
			
		}
		catch (FileNotFoundException fnf) {
			// nada
		}
		catch (IOException io1) {
			// nada
		}

		
	}
	
	public void loadLanguageFile() {
		String[] langfile = new String[count];
		String filename = "";
		
		JFileChooser chooser = new JFileChooser("./cfg");
		int returnVal = chooser.showOpenDialog(JHotel_Translator.this);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			filename = (chooser.getSelectedFile().getPath());
		}
		
		
		
		try {
			FileInputStream fis = new FileInputStream(filename);
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			langfile = (String[]) ois.readObject();
			ois.close();
		}
		catch (IOException io1) {
			// nada
		}
		catch (ClassNotFoundException cnf) {
			// nada
		}
		
		jTextField.setText(langfile[0]);
		jTextField1.setText(langfile[1]);
		jTextField2.setText(langfile[2]);
		jTextField3.setText(langfile[3]);
		jTextField4.setText(langfile[4]);
		jTextField5.setText(langfile[5]);
		jTextField6.setText(langfile[6]);
		jTextField7.setText(langfile[7]);
		jTextField8.setText(langfile[8]);
		jTextField9.setText(langfile[9]);
		jTextField10.setText(langfile[10]);
		jTextField11.setText(langfile[11]);
		jTextField12.setText(langfile[12]);
		jTextField13.setText(langfile[13]);
		jTextField14.setText(langfile[14]);
		jTextField15.setText(langfile[15]);
		jTextField16.setText(langfile[16]);
		jTextField17.setText(langfile[17]);
		jTextField18.setText(langfile[18]);
		jTextField19.setText(langfile[19]);
		jTextField20.setText(langfile[20]);
		jTextField21.setText(langfile[21]);
		jTextField22.setText(langfile[22]);
		jTextField23.setText(langfile[23]);
		jTextField24.setText(langfile[24]);
		jTextField25.setText(langfile[25]);
		jTextField26.setText(langfile[26]);
		jTextField27.setText(langfile[27]);
		jTextField28.setText(langfile[28]);
		jTextField29.setText(langfile[29]);
		jTextField30.setText(langfile[30]);
		jTextField31.setText(langfile[31]);
		jTextField32.setText(langfile[32]);
		jTextField33.setText(langfile[33]);
		jTextField34.setText(langfile[34]);
		jTextField35.setText(langfile[35]);
		jTextField36.setText(langfile[36]);
		jTextField37.setText(langfile[37]);
		jTextField38.setText(langfile[38]);
		jTextField39.setText(langfile[39]);
		jTextField40.setText(langfile[40]);
		jTextField41.setText(langfile[41]);
		jTextField42.setText(langfile[42]);
		jTextField43.setText(langfile[43]);
		jTextField44.setText(langfile[44]);
		jTextField45.setText(langfile[45]);
		jTextField46.setText(langfile[46]);
		jTextField47.setText(langfile[47]);
		jTextField48.setText(langfile[48]);
		jTextField49.setText(langfile[49]);
		jTextField50.setText(langfile[50]);
		jTextField51.setText(langfile[51]);
		jTextArea1.setText(langfile[52]);
		jTextArea3.setText(langfile[53]);
		jTextField52.setText(langfile[54]);
		jTextField53.setText(langfile[55]);
		jTextField54.setText(langfile[56]);
		jTextField55.setText(langfile[57]);
		jTextField56.setText(langfile[58]);
		jTextField57.setText(langfile[59]);
		jTextField58.setText(langfile[60]);
		jTextField59.setText(langfile[61]);
		jTextField60.setText(langfile[62]);
		jTextField61.setText(langfile[63]);
		jTextField62.setText(langfile[64]);
		jTextField63.setText(langfile[65]);
		jTextField64.setText(langfile[66]);
		jTextField65.setText(langfile[67]);
		jTextField66.setText(langfile[68]);
		jTextField67.setText(langfile[69]);
		jTextField68.setText(langfile[70]);
		jTextField69.setText(langfile[71]);
		jTextField70.setText(langfile[72]);
		jTextField71.setText(langfile[73]);
		jTextField72.setText(langfile[74]);
		jTextField73.setText(langfile[75]);
		jTextField74.setText(langfile[76]);
		jTextField75.setText(langfile[77]);
		jTextField76.setText(langfile[78]);
		jTextField77.setText(langfile[79]);
		jTextField78.setText(langfile[80]);
		jTextField79.setText(langfile[81]);
		jTextField80.setText(langfile[82]);
		jTextField81.setText(langfile[83]);
		jTextField82.setText(langfile[84]);
		jTextField83.setText(langfile[85]);
		jTextField84.setText(langfile[86]);
		jTextField85.setText(langfile[87]);
		jTextField86.setText(langfile[88]);
		jTextField87.setText(langfile[89]);
		jTextField88.setText(langfile[90]);
		jTextField89.setText(langfile[91]);
		jTextField90.setText(langfile[92]);
		jTextField91.setText(langfile[93]);
		jTextField92.setText(langfile[94]);
		jTextField93.setText(langfile[95]);
		jTextField94.setText(langfile[96]);
		jTextField95.setText(langfile[97]);
		jTextField96.setText(langfile[98]);
		jTextField97.setText(langfile[99]);
		jTextField98.setText(langfile[100]);
		jTextField99.setText(langfile[101]);
		jTextField100.setText(langfile[102]);
		jTextField101.setText(langfile[103]);
		jTextField102.setText(langfile[104]);
		jTextField103.setText(langfile[105]);
		jTextField104.setText(langfile[106]);
		jTextField105.setText(langfile[107]);
		jTextField106.setText(langfile[108]);
		jTextField107.setText(langfile[109]);
		jTextField108.setText(langfile[110]);
		jTextField109.setText(langfile[111]);
		jTextField110.setText(langfile[112]);
		jTextField111.setText(langfile[113]);
		jTextField112.setText(langfile[114]);
		jTextField113.setText(langfile[115]);
		jTextField114.setText(langfile[116]);
		jTextField115.setText(langfile[117]);
		jTextField116.setText(langfile[118]);



		
		
	}

	public void clearFields() {
		
		jTextField.setText("");
		jTextField1.setText("");
		jTextField2.setText("");
		jTextField3.setText("");
		jTextField4.setText("");
		jTextField5.setText("");
		jTextField6.setText("");
		jTextField7.setText("");
		jTextField8.setText("");
		jTextField9.setText("");
		jTextField10.setText("");
		jTextField11.setText("");
		jTextField12.setText("");
		jTextField13.setText("");
		jTextField14.setText("");
		jTextField15.setText("");
		jTextField16.setText("");
		jTextField17.setText("");
		jTextField18.setText("");
		jTextField19.setText("");
		jTextField20.setText("");
		jTextField21.setText("");
		jTextField22.setText("");
		jTextField23.setText("");
		jTextField24.setText("");
		jTextField25.setText("");
		jTextField26.setText("");
		jTextField27.setText("");
		jTextField28.setText("");
		jTextField29.setText("");
		jTextField30.setText("");
		jTextField31.setText("");
		jTextField32.setText("");
		jTextField33.setText("");
		jTextField34.setText("");
		jTextField35.setText("");
		jTextField36.setText("");
		jTextField37.setText("");
		jTextField38.setText("");
		jTextField39.setText("");
		jTextField40.setText("");
		jTextField41.setText("");
		jTextField42.setText("");
		jTextField43.setText("");
		jTextField44.setText("");
		jTextField45.setText("");
		jTextField46.setText("");
		jTextField47.setText("");
		jTextField48.setText("");
		jTextField49.setText("");
		jTextField50.setText("");
		jTextField51.setText("");
		jTextField52.setText("");
		jTextField53.setText("");
		jTextField54.setText("");
		jTextField55.setText("");
		jTextField56.setText("");
		jTextField57.setText("");
		jTextField58.setText("");
		jTextField59.setText("");
		jTextField60.setText("");
		jTextField61.setText("");
		jTextField62.setText("");
		jTextField63.setText("");
		jTextField64.setText("");
		jTextField65.setText("");
		jTextField66.setText("");
		jTextField67.setText("");
		jTextField68.setText("");
		jTextField69.setText("");
		jTextField70.setText("");
		jTextField71.setText("");
		jTextField72.setText("");
		jTextField73.setText("");
		jTextField74.setText("");
		jTextField75.setText("");
		jTextField76.setText("");
		jTextField77.setText("");
		jTextField78.setText("");
		jTextField79.setText("");
		jTextField80.setText("");
		jTextField81.setText("");
		jTextField82.setText("");
		jTextField83.setText("");
		jTextField84.setText("");
		jTextField85.setText("");
		jTextField86.setText("");
		jTextField87.setText("");
		jTextField88.setText("");
		jTextField89.setText("");
		jTextField90.setText("");
		jTextField91.setText("");
		jTextField92.setText("");
		jTextField93.setText("");
		jTextField94.setText("");
		jTextField95.setText("");
		jTextField96.setText("");
		jTextField97.setText("");
		jTextField98.setText("");
		jTextField99.setText("");
		jTextField100.setText("");
		jTextField101.setText("");
		jTextField102.setText("");
		jTextField103.setText("");
		jTextField104.setText("");
		jTextField105.setText("");
		jTextField106.setText("");
		jTextField107.setText("");
		jTextField108.setText("");
		jTextField109.setText("");
		jTextField110.setText("");
		jTextField111.setText("");
		jTextField112.setText("");
		jTextField113.setText("");
		jTextField114.setText("");
		jTextField115.setText("");
		jTextField116.setText("");
		jTextArea1.setText("");
		jTextArea3.setText("");

		jPanel1.setVisible(false);
		jPanel.setVisible(true);
		jButton.setVisible(true);
		jButton1.setVisible(false);
		jButton2.setVisible(false);
		jButton3.setVisible(true);
		
		
	}





	/**
	 * This method initializes jButton3
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton3() {
		if(jButton3 == null) {
			jButton3 = new javax.swing.JButton();
			jButton3.setVisible(true);
			jButton3.setText("Load language file");
			jButton3.setBounds(17, 597, 150, 23);
			jButton3.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					loadLanguageFile();
				}
			});
		}
		return jButton3;
	}
	/**
	 * This method initializes jPanel2
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJPanel2() {
		if(jPanel2 == null) {
			jPanel2 = new javax.swing.JPanel();
			jPanel2.setLayout(null);
			jPanel2.add(getJLabel52(), null);
			jPanel2.add(getJLabel53(), null);
			jPanel2.add(getJTextField52(), null);
			jPanel2.add(getJTextField53(), null);
			jPanel2.add(getJLabel54(), null);
			jPanel2.add(getJLabel55(), null);
			jPanel2.add(getJLabel56(), null);
			jPanel2.add(getJLabel57(), null);
			jPanel2.add(getJLabel58(), null);
			jPanel2.add(getJLabel59(), null);
			jPanel2.add(getJLabel60(), null);
			jPanel2.add(getJLabel61(), null);
			jPanel2.add(getJLabel62(), null);
			jPanel2.add(getJLabel63(), null);
			jPanel2.add(getJLabel64(), null);
			jPanel2.add(getJTextField54(), null);
			jPanel2.add(getJTextField55(), null);
			jPanel2.add(getJTextField56(), null);
			jPanel2.add(getJTextField57(), null);
			jPanel2.add(getJTextField58(), null);
			jPanel2.add(getJTextField59(), null);
			jPanel2.add(getJTextField60(), null);
			jPanel2.add(getJTextField61(), null);
			jPanel2.add(getJTextField62(), null);
			jPanel2.add(getJTextField63(), null);
			jPanel2.add(getJTextField64(), null);
			jPanel2.add(getJLabel65(), null);
			jPanel2.add(getJLabel66(), null);
			jPanel2.add(getJLabel67(), null);
			jPanel2.add(getJLabel68(), null);
			jPanel2.add(getJLabel69(), null);
			jPanel2.add(getJLabel70(), null);
			jPanel2.add(getJLabel71(), null);
			jPanel2.add(getJLabel72(), null);
			jPanel2.add(getJLabel73(), null);
			jPanel2.add(getJLabel74(), null);
			jPanel2.add(getJTextField65(), null);
			jPanel2.add(getJLabel75(), null);
			jPanel2.add(getJLabel76(), null);
			jPanel2.add(getJLabel77(), null);
			jPanel2.add(getJTextField66(), null);
			jPanel2.add(getJTextField67(), null);
			jPanel2.add(getJTextField68(), null);
			jPanel2.add(getJTextField69(), null);
			jPanel2.add(getJTextField70(), null);
			jPanel2.add(getJTextField71(), null);
			jPanel2.add(getJTextField72(), null);
			jPanel2.add(getJTextField73(), null);
			jPanel2.add(getJTextField74(), null);
			jPanel2.add(getJTextField75(), null);
			jPanel2.add(getJTextField76(), null);
			jPanel2.add(getJTextField77(), null);
			jPanel2.setBounds(17, 90, 908, 502);
			jPanel2.setBackground(java.awt.SystemColor.window);
			jPanel2.setVisible(false);
		}
		return jPanel2;
	}
	/**
	 * This method initializes jLabel52
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel52() {
		if(jLabel52 == null) {
			jLabel52 = new javax.swing.JLabel();
			jLabel52.setBounds(20, 19, 182, 24);
			jLabel52.setText("Rooms");
		}
		return jLabel52;
	}
	/**
	 * This method initializes jLabel53
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel53() {
		if(jLabel53 == null) {
			jLabel53 = new javax.swing.JLabel();
			jLabel53.setBounds(20, 54, 182, 24);
			jLabel53.setText("Single room");
		}
		return jLabel53;
	}
	/**
	 * This method initializes jTextField52
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField52() {
		if(jTextField52 == null) {
			jTextField52 = new javax.swing.JTextField();
			jTextField52.setBounds(208, 19, 238, 24);
		}
		return jTextField52;
	}
	/**
	 * This method initializes jTextField53
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField53() {
		if(jTextField53 == null) {
			jTextField53 = new javax.swing.JTextField();
			jTextField53.setBounds(208, 54, 238, 24);
		}
		return jTextField53;
	}
	/**
	 * This method initializes jLabel54
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel54() {
		if(jLabel54 == null) {
			jLabel54 = new javax.swing.JLabel();
			jLabel54.setBounds(20, 88, 182, 25);
			jLabel54.setText("Double room");
		}
		return jLabel54;
	}
	/**
	 * This method initializes jLabel55
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel55() {
		if(jLabel55 == null) {
			jLabel55 = new javax.swing.JLabel();
			jLabel55.setBounds(20, 124, 182, 23);
			jLabel55.setText("Triple room");
		}
		return jLabel55;
	}
	/**
	 * This method initializes jLabel56
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel56() {
		if(jLabel56 == null) {
			jLabel56 = new javax.swing.JLabel();
			jLabel56.setBounds(20, 159, 182, 24);
			jLabel56.setText("Four-bed room");
		}
		return jLabel56;
	}
	/**
	 * This method initializes jLabel57
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel57() {
		if(jLabel57 == null) {
			jLabel57 = new javax.swing.JLabel();
			jLabel57.setBounds(20, 194, 182, 24);
			jLabel57.setText("Apartment/Suite");
		}
		return jLabel57;
	}
	/**
	 * This method initializes jLabel58
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel58() {
		if(jLabel58 == null) {
			jLabel58 = new javax.swing.JLabel();
			jLabel58.setBounds(20, 229, 182, 24);
			jLabel58.setText("Arrival");
		}
		return jLabel58;
	}
	/**
	 * This method initializes jLabel59
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel59() {
		if(jLabel59 == null) {
			jLabel59 = new javax.swing.JLabel();
			jLabel59.setBounds(20, 264, 182, 24);
			jLabel59.setText("Departure");
		}
		return jLabel59;
	}
	/**
	 * This method initializes jLabel60
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel60() {
		if(jLabel60 == null) {
			jLabel60 = new javax.swing.JLabel();
			jLabel60.setBounds(20, 299, 182, 24);
			jLabel60.setText("Choose guest");
		}
		return jLabel60;
	}
	/**
	 * This method initializes jLabel61
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel61() {
		if(jLabel61 == null) {
			jLabel61 = new javax.swing.JLabel();
			jLabel61.setBounds(20, 334, 182, 24);
			jLabel61.setText("Calendar");
		}
		return jLabel61;
	}
	/**
	 * This method initializes jLabel62
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel62() {
		if(jLabel62 == null) {
			jLabel62 = new javax.swing.JLabel();
			jLabel62.setBounds(20, 369, 182, 24);
			jLabel62.setText("Nights");
		}
		return jLabel62;
	}
	/**
	 * This method initializes jLabel63
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel63() {
		if(jLabel63 == null) {
			jLabel63 = new javax.swing.JLabel();
			jLabel63.setBounds(20, 404, 182, 24);
			jLabel63.setText("Loading...");
		}
		return jLabel63;
	}
	/**
	 * This method initializes jLabel64
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel64() {
		if(jLabel64 == null) {
			jLabel64 = new javax.swing.JLabel();
			jLabel64.setBounds(20, 439, 182, 24);
			jLabel64.setText("Updating...");
		}
		return jLabel64;
	}
	/**
	 * This method initializes jTextField54
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField54() {
		if(jTextField54 == null) {
			jTextField54 = new javax.swing.JTextField();
			jTextField54.setNextFocusableComponent(getJTextField55());
			jTextField54.setBounds(208, 88, 238, 24);
		}
		return jTextField54;
	}
	/**
	 * This method initializes jTextField55
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField55() {
		if(jTextField55 == null) {
			jTextField55 = new javax.swing.JTextField();
			jTextField55.setNextFocusableComponent(getJTextField56());
			jTextField55.setBounds(208, 124, 238, 24);
		}
		return jTextField55;
	}
	/**
	 * This method initializes jTextField56
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField56() {
		if(jTextField56 == null) {
			jTextField56 = new javax.swing.JTextField();
			jTextField56.setNextFocusableComponent(getJTextField57());
			jTextField56.setBounds(208, 159, 238, 24);
		}
		return jTextField56;
	}
	/**
	 * This method initializes jTextField57
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField57() {
		if(jTextField57 == null) {
			jTextField57 = new javax.swing.JTextField();
			jTextField57.setNextFocusableComponent(getJTextField58());
			jTextField57.setBounds(208, 194, 238, 24);
		}
		return jTextField57;
	}
	/**
	 * This method initializes jTextField58
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField58() {
		if(jTextField58 == null) {
			jTextField58 = new javax.swing.JTextField();
			jTextField58.setNextFocusableComponent(getJTextField59());
			jTextField58.setBounds(208, 229, 238, 24);
		}
		return jTextField58;
	}
	/**
	 * This method initializes jTextField59
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField59() {
		if(jTextField59 == null) {
			jTextField59 = new javax.swing.JTextField();
			jTextField59.setNextFocusableComponent(getJTextField60());
			jTextField59.setBounds(208, 264, 238, 24);
		}
		return jTextField59;
	}
	/**
	 * This method initializes jTextField60
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField60() {
		if(jTextField60 == null) {
			jTextField60 = new javax.swing.JTextField();
			jTextField60.setNextFocusableComponent(getJTextField61());
			jTextField60.setBounds(208, 299, 238, 24);
		}
		return jTextField60;
	}
	/**
	 * This method initializes jTextField61
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField61() {
		if(jTextField61 == null) {
			jTextField61 = new javax.swing.JTextField();
			jTextField61.setNextFocusableComponent(getJTextField62());
			jTextField61.setBounds(208, 334, 238, 24);
		}
		return jTextField61;
	}
	/**
	 * This method initializes jTextField62
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField62() {
		if(jTextField62 == null) {
			jTextField62 = new javax.swing.JTextField();
			jTextField62.setNextFocusableComponent(getJTextField63());
			jTextField62.setBounds(208, 369, 238, 24);
		}
		return jTextField62;
	}
	/**
	 * This method initializes jTextField63
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField63() {
		if(jTextField63 == null) {
			jTextField63 = new javax.swing.JTextField();
			jTextField63.setNextFocusableComponent(getJTextField64());
			jTextField63.setBounds(208, 404, 238, 24);
		}
		return jTextField63;
	}
	/**
	 * This method initializes jTextField64
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField64() {
		if(jTextField64 == null) {
			jTextField64 = new javax.swing.JTextField();
			jTextField64.setNextFocusableComponent(getJTextField65());
			jTextField64.setBounds(208, 439, 238, 24);
		}
		return jTextField64;
	}
	/**
	 * This method initializes jLabel65
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel65() {
		if(jLabel65 == null) {
			jLabel65 = new javax.swing.JLabel();
			jLabel65.setBounds(478, 19, 182, 24);
			jLabel65.setText("Resolution (Display)");
		}
		return jLabel65;
	}
	/**
	 * This method initializes jLabel66
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel66() {
		if(jLabel66 == null) {
			jLabel66 = new javax.swing.JLabel();
			jLabel66.setBounds(478, 54, 182, 24);
			jLabel66.setText("January");
		}
		return jLabel66;
	}
	/**
	 * This method initializes jLabel67
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel67() {
		if(jLabel67 == null) {
			jLabel67 = new javax.swing.JLabel();
			jLabel67.setBounds(478, 88, 182, 24);
			jLabel67.setText("February");
		}
		return jLabel67;
	}
	/**
	 * This method initializes jLabel68
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel68() {
		if(jLabel68 == null) {
			jLabel68 = new javax.swing.JLabel();
			jLabel68.setBounds(478, 124, 182, 24);
			jLabel68.setText("March");
		}
		return jLabel68;
	}
	/**
	 * This method initializes jLabel69
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel69() {
		if(jLabel69 == null) {
			jLabel69 = new javax.swing.JLabel();
			jLabel69.setBounds(478, 159, 182, 24);
			jLabel69.setText("April");
		}
		return jLabel69;
	}
	/**
	 * This method initializes jLabel70
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel70() {
		if(jLabel70 == null) {
			jLabel70 = new javax.swing.JLabel();
			jLabel70.setBounds(478, 194, 182, 24);
			jLabel70.setText("May");
		}
		return jLabel70;
	}
	/**
	 * This method initializes jLabel71
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel71() {
		if(jLabel71 == null) {
			jLabel71 = new javax.swing.JLabel();
			jLabel71.setBounds(478, 229, 182, 24);
			jLabel71.setText("June");
		}
		return jLabel71;
	}
	/**
	 * This method initializes jLabel72
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel72() {
		if(jLabel72 == null) {
			jLabel72 = new javax.swing.JLabel();
			jLabel72.setBounds(478, 264, 182, 24);
			jLabel72.setText("July");
		}
		return jLabel72;
	}
	/**
	 * This method initializes jLabel73
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel73() {
		if(jLabel73 == null) {
			jLabel73 = new javax.swing.JLabel();
			jLabel73.setBounds(478, 299, 182, 24);
			jLabel73.setText("August");
		}
		return jLabel73;
	}
	/**
	 * This method initializes jLabel74
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel74() {
		if(jLabel74 == null) {
			jLabel74 = new javax.swing.JLabel();
			jLabel74.setBounds(478, 334, 182, 24);
			jLabel74.setText("September");
		}
		return jLabel74;
	}
	/**
	 * This method initializes jTextField65
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField65() {
		if(jTextField65 == null) {
			jTextField65 = new javax.swing.JTextField();
			jTextField65.setNextFocusableComponent(getJTextField66());
			jTextField65.setBounds(663, 19, 238, 24);
		}
		return jTextField65;
	}
	/**
	 * This method initializes jLabel75
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel75() {
		if(jLabel75 == null) {
			jLabel75 = new javax.swing.JLabel();
			jLabel75.setBounds(478, 369, 182, 24);
			jLabel75.setText("October");
		}
		return jLabel75;
	}
	/**
	 * This method initializes jLabel76
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel76() {
		if(jLabel76 == null) {
			jLabel76 = new javax.swing.JLabel();
			jLabel76.setBounds(478, 404, 182, 24);
			jLabel76.setText("November");
		}
		return jLabel76;
	}
	/**
	 * This method initializes jLabel77
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel77() {
		if(jLabel77 == null) {
			jLabel77 = new javax.swing.JLabel();
			jLabel77.setBounds(478, 439, 182, 24);
			jLabel77.setText("December");
		}
		return jLabel77;
	}
	/**
	 * This method initializes jTextField66
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField66() {
		if(jTextField66 == null) {
			jTextField66 = new javax.swing.JTextField();
			jTextField66.setNextFocusableComponent(getJTextField67());
			jTextField66.setBounds(663, 54, 238, 24);
		}
		return jTextField66;
	}
	/**
	 * This method initializes jTextField67
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField67() {
		if(jTextField67 == null) {
			jTextField67 = new javax.swing.JTextField();
			jTextField67.setNextFocusableComponent(getJTextField68());
			jTextField67.setBounds(663, 88, 238, 24);
		}
		return jTextField67;
	}
	/**
	 * This method initializes jTextField68
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField68() {
		if(jTextField68 == null) {
			jTextField68 = new javax.swing.JTextField();
			jTextField68.setNextFocusableComponent(getJTextField69());
			jTextField68.setBounds(663, 124, 238, 24);
		}
		return jTextField68;
	}
	/**
	 * This method initializes jTextField69
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField69() {
		if(jTextField69 == null) {
			jTextField69 = new javax.swing.JTextField();
			jTextField69.setNextFocusableComponent(getJTextField70());
			jTextField69.setBounds(663, 159, 238, 24);
		}
		return jTextField69;
	}
	/**
	 * This method initializes jTextField70
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField70() {
		if(jTextField70 == null) {
			jTextField70 = new javax.swing.JTextField();
			jTextField70.setNextFocusableComponent(getJTextField71());
			jTextField70.setBounds(663, 194, 238, 24);
		}
		return jTextField70;
	}
	/**
	 * This method initializes jTextField71
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField71() {
		if(jTextField71 == null) {
			jTextField71 = new javax.swing.JTextField();
			jTextField71.setNextFocusableComponent(getJTextField72());
			jTextField71.setBounds(663, 229, 238, 24);
		}
		return jTextField71;
	}
	/**
	 * This method initializes jTextField72
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField72() {
		if(jTextField72 == null) {
			jTextField72 = new javax.swing.JTextField();
			jTextField72.setNextFocusableComponent(getJTextField73());
			jTextField72.setBounds(663, 264, 238, 24);
		}
		return jTextField72;
	}
	/**
	 * This method initializes jTextField73
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField73() {
		if(jTextField73 == null) {
			jTextField73 = new javax.swing.JTextField();
			jTextField73.setNextFocusableComponent(getJTextField74());
			jTextField73.setBounds(663, 299, 238, 24);
		}
		return jTextField73;
	}
	/**
	 * This method initializes jTextField74
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField74() {
		if(jTextField74 == null) {
			jTextField74 = new javax.swing.JTextField();
			jTextField74.setNextFocusableComponent(getJTextField75());
			jTextField74.setBounds(663, 334, 238, 24);
		}
		return jTextField74;
	}
	/**
	 * This method initializes jTextField75
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField75() {
		if(jTextField75 == null) {
			jTextField75 = new javax.swing.JTextField();
			jTextField75.setNextFocusableComponent(getJTextField76());
			jTextField75.setBounds(663, 369, 238, 24);
		}
		return jTextField75;
	}
	/**
	 * This method initializes jTextField76
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField76() {
		if(jTextField76 == null) {
			jTextField76 = new javax.swing.JTextField();
			jTextField76.setNextFocusableComponent(getJTextField77());
			jTextField76.setBounds(663, 404, 238, 24);
		}
		return jTextField76;
	}
	/**
	 * This method initializes jTextField77
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField77() {
		if(jTextField77 == null) {
			jTextField77 = new javax.swing.JTextField();
			jTextField77.setNextFocusableComponent(getJTextField77());
			jTextField77.setBounds(663, 439, 238, 24);
		}
		return jTextField77;
	}
	/**
	 * This method initializes jButton4
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton4() {
		if(jButton4 == null) {
			jButton4 = new javax.swing.JButton();
			jButton4.setBounds(784, 598, 141, 23);
			jButton4.setText("Next");
			jButton4.setVisible(false);
			jButton4.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					jPanel.setVisible(false);
					jPanel1.setVisible(false);
					jPanel2.setVisible(true);
					jPanel3.setVisible(false);
					jButton.setVisible(false);
					jButton1.setVisible(false);
					jButton5.setVisible(true);
					jButton6.setVisible(true);
					jButton7.setVisible(false);
					jButton3.setVisible(false);
					jButton4.setVisible(false);
					jButton2.setVisible(false);

				}
			});
		}
		return jButton4;
	}
	/**
	 * This method initializes jButton5
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton5() {
		if(jButton5 == null) {
			jButton5 = new javax.swing.JButton();
			jButton5.setBounds(17, 598, 141, 23);
			jButton5.setText("Back");
			jButton5.setVisible(false);
			jButton5.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					jPanel1.setVisible(true);
					jPanel2.setVisible(false);
					jButton.setVisible(false);
					jButton4.setVisible(true);
					jButton2.setVisible(true);
					jButton3.setVisible(false);
					jButton5.setVisible(false);
					jButton1.setVisible(false);
				}
			});
		}
		return jButton5;
	}
	
	
	/**
	 * This method initializes jPanel3
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJPanel3() {
		if(jPanel3 == null) {
			jPanel3 = new javax.swing.JPanel();
			jPanel3.setLayout(null);
			jPanel3.add(getJLabel78(), null);
			jPanel3.add(getJLabel79(), null);
			jPanel3.add(getJLabel80(), null);
			jPanel3.add(getJLabel81(), null);
			jPanel3.add(getJLabel82(), null);
			jPanel3.add(getJLabel83(), null);
			jPanel3.add(getJLabel84(), null);
			jPanel3.add(getJLabel85(), null);
			jPanel3.add(getJLabel86(), null);
			jPanel3.add(getJLabel87(), null);
			jPanel3.add(getJLabel88(), null);
			jPanel3.add(getJLabel89(), null);
			jPanel3.add(getJLabel90(), null);
			jPanel3.add(getJLabel91(), null);
			jPanel3.add(getJLabel92(), null);
			jPanel3.add(getJLabel93(), null);
			jPanel3.add(getJLabel94(), null);
			jPanel3.add(getJLabel95(), null);
			jPanel3.add(getJLabel96(), null);
			jPanel3.add(getJLabel97(), null);
			jPanel3.add(getJLabel98(), null);
			jPanel3.add(getJLabel99(), null);
			jPanel3.add(getJLabel100(), null);
			jPanel3.add(getJLabel101(), null);
			jPanel3.add(getJLabel102(), null);
			jPanel3.add(getJLabel103(), null);
			jPanel3.add(getJLabel104(), null);
			jPanel3.add(getJLabel105(), null);
			jPanel3.add(getJLabel106(), null);
			jPanel3.add(getJLabel107(), null);
			jPanel3.add(getJLabel108(), null);
			jPanel3.add(getJLabel109(), null);
			jPanel3.add(getJLabel110(), null);
			jPanel3.add(getJLabel111(), null);
			jPanel3.add(getJLabel112(), null);
			jPanel3.add(getJLabel113(), null);
			jPanel3.add(getJLabel114(), null);
			jPanel3.add(getJLabel115(), null);
			jPanel3.add(getJLabel116(), null);
			jPanel3.add(getJTextField78(), null);
			jPanel3.add(getJTextField79(), null);
			jPanel3.add(getJTextField80(), null);
			jPanel3.add(getJTextField81(), null);
			jPanel3.add(getJTextField82(), null);
			jPanel3.add(getJTextField83(), null);
			jPanel3.add(getJTextField84(), null);
			jPanel3.add(getJTextField85(), null);
			jPanel3.add(getJTextField86(), null);
			jPanel3.add(getJTextField87(), null);
			jPanel3.add(getJTextField88(), null);
			jPanel3.add(getJTextField89(), null);
			jPanel3.add(getJTextField90(), null);
			jPanel3.add(getJTextField91(), null);
			jPanel3.add(getJTextField92(), null);
			jPanel3.add(getJTextField93(), null);
			jPanel3.add(getJTextField94(), null);
			jPanel3.add(getJTextField95(), null);
			jPanel3.add(getJTextField96(), null);
			jPanel3.add(getJTextField97(), null);
			jPanel3.add(getJTextField98(), null);
			jPanel3.add(getJTextField99(), null);
			jPanel3.add(getJTextField100(), null);
			jPanel3.add(getJTextField101(), null);
			jPanel3.add(getJTextField102(), null);
			jPanel3.add(getJTextField103(), null);		
			jPanel3.add(getJTextField104(), null);
			jPanel3.add(getJTextField105(), null);
			jPanel3.add(getJTextField106(), null);
			jPanel3.add(getJTextField107(), null);
			jPanel3.add(getJTextField108(), null);
			jPanel3.add(getJTextField109(), null);
			jPanel3.add(getJTextField110(), null);
			jPanel3.add(getJTextField111(), null);
			jPanel3.add(getJTextField112(), null);
			jPanel3.add(getJTextField113(), null);
			jPanel3.add(getJTextField114(), null);
			jPanel3.add(getJTextField115(), null);
			jPanel3.add(getJTextField116(), null);

			jPanel3.setBounds(17, 90, 908, 502);
			jPanel3.setVisible(false);
			jPanel3.setBackground(java.awt.SystemColor.window);
			
		}
		return jPanel3;
		}
		
	
	private javax.swing.JLabel getJLabel78() {
		if(jLabel78 == null) {
			jLabel78 = new javax.swing.JLabel();
			jLabel78.setBounds(20, 19, 91, 24);
			jLabel78.setText("Deleting");
		}
		return jLabel78;
	}
	/**
	 * This method initializes jLabel1
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel79() {
		if(jLabel79 == null) {
			jLabel79 = new javax.swing.JLabel();
			jLabel79.setBounds(20, 54, 91, 24);
			jLabel79.setText("Change");
		}
		return jLabel79;
	}
	/**
	 * This method initializes jLabel2
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel80() {
		if(jLabel80 == null) {
			jLabel80 = new javax.swing.JLabel();
			jLabel80.setBounds(20, 89, 91, 24);
			jLabel80.setText("Reservation");
		}
		return jLabel80;
	}
	/**
	 * This method initializes jLabel3
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel81() {
		if(jLabel81== null) {
			jLabel81 = new javax.swing.JLabel();
			jLabel81.setBounds(20, 124, 91, 24);
			jLabel81.setText("Are you sure?");
		}
		return jLabel81;
	}
	/**
	 * This method initializes jLabel4
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel82() {
		if(jLabel82 == null) {
			jLabel82 = new javax.swing.JLabel();
			jLabel82.setBounds(20, 159, 91, 24);
			jLabel82.setText("Floor");
		}
		return jLabel82;
	}
	/**
	 * This method initializes jLabel5
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel83() {
		if(jLabel83 == null) {
			jLabel83 = new javax.swing.JLabel();
			jLabel83.setBounds(20, 194, 98, 24);
			jLabel83.setText("Avail. rooms");
			jLabel83.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 12));
		}
		return jLabel83;
	}
	/**
	 * This method initializes jLabel6
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel84() {
		if(jLabel84 == null) {
			jLabel84 = new javax.swing.JLabel();
			jLabel84.setBounds(20, 229, 91, 24);
			jLabel84.setText("Select room");
		}
		return jLabel84;
	}
	/**
	 * This method initializes jLabel7
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel85() {
		if(jLabel85 == null) {
			jLabel85 = new javax.swing.JLabel();
			jLabel85.setBounds(20, 264, 91, 24);
			jLabel85.setText("About");
		}
		return jLabel85;
	}
	/**
	 * This method initializes jLabel8
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel86() {
		if(jLabel86 == null) {
			jLabel86 = new javax.swing.JLabel();
			jLabel86.setBounds(20, 299, 91, 24);
			jLabel86.setText("Help");
		}
		return jLabel86;
	}
	/**
	 * This method initializes jLabel9
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel87() {
		if(jLabel87 == null) {
			jLabel87 = new javax.swing.JLabel();
			jLabel87.setBounds(20, 334, 91, 24);
			jLabel87.setText("Checkin Management");
		}
		return jLabel87;
	}
	/**
	 * This method initializes jLabel10
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel88() {
		if(jLabel88 == null) {
			jLabel88 = new javax.swing.JLabel();
			jLabel88.setBounds(20, 369, 91, 24);
			jLabel88.setText("Price");
		}
		return jLabel88;
	}
	/**
	 * This method initializes jLabel89
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel89() {
		if(jLabel89 == null) {
			jLabel89 = new javax.swing.JLabel();
			jLabel89.setBounds(20, 404, 91, 24);
			jLabel89.setText("Currency");
		}
		return jLabel89;
	}
	/**
	 * This method initializes jLabel12
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel90() {
		if(jLabel90 == null) {
			jLabel90 = new javax.swing.JLabel();
			jLabel90.setBounds(20, 439, 91, 24);
			jLabel90.setText("Checked in");
		}
		return jLabel90;
	}
	/**
	 * This method initializes jLabel13
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel91() {
		if(jLabel91 == null) {
			jLabel91 = new javax.swing.JLabel();
			jLabel91.setBounds(316, 19, 91, 24);
			jLabel91.setText("Other date");
		}
		return jLabel91;
	}
	/**
	 * This method initializes jLabel14
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel92() {
		if(jLabel92 == null) {
			jLabel92 = new javax.swing.JLabel();
			jLabel92.setBounds(316, 54, 91, 24);
			jLabel92.setText("JLabel");
		}
		return jLabel92;
	}
	/**
	 * This method initializes jLabel15
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel93() {
		if(jLabel93 == null) {
			jLabel93 = new javax.swing.JLabel();
			jLabel93.setBounds(316, 89, 91, 24);
			jLabel93.setText("JLabel");
		}
		return jLabel93;
	}
	/**
	 * This method initializes jLabel16
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel94() {
		if(jLabel94 == null) {
			jLabel94 = new javax.swing.JLabel();
			jLabel94.setBounds(316, 124, 91, 24);
			jLabel94.setText("JLabel");
		}
		return jLabel94;
	}
	
	/**
	 * This method initializes jLabel95
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel95() {
		if(jLabel95 == null) {
			jLabel95 = new javax.swing.JLabel();
			jLabel95.setBounds(316, 159, 91, 24);
			jLabel95.setText("JLabel");
		}
		return jLabel95;
	}
	/**
	 * This method initializes jLabel18
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel96() {
		if(jLabel96 == null) {
			jLabel96 = new javax.swing.JLabel();
			jLabel96.setBounds(316, 194, 91, 24);
			jLabel96.setText("JLabel");
		}
		return jLabel96;
	}
	/**
	 * This method initializes jLabel19
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel97() {
		if(jLabel97 == null) {
			jLabel97 = new javax.swing.JLabel();
			jLabel97.setBounds(316, 229, 91, 24);
			jLabel97.setText("JLabel");
		}
		return jLabel97;
	}
	/**
	 * This method initializes jLabel20
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel98() {
		if(jLabel98 == null) {
			jLabel98 = new javax.swing.JLabel();
			jLabel98.setBounds(316, 264, 91, 24);
			jLabel98.setText("JLabel");
		}
		return jLabel98;
	}
	/**
	 * This method initializes jLabel21
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel99() {
		if(jLabel99 == null) {
			jLabel99 = new javax.swing.JLabel();
			jLabel99.setBounds(316, 299, 91, 24);
			jLabel99.setText("JLabel");
		}
		return jLabel99;
	}
	/**
	 * This method initializes jLabel22
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel100() {
		if(jLabel100 == null) {
			jLabel100 = new javax.swing.JLabel();
			jLabel100.setBounds(316, 334, 91, 24);
			jLabel100.setText("JLabel");
		}
		return jLabel100;
	}
	/**
	 * This method initializes jLabel23
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel101() {
		if(jLabel101 == null) {
			jLabel101 = new javax.swing.JLabel();
			jLabel101.setBounds(316, 369, 91, 24);
			jLabel101.setText("JLabel");
		}
		return jLabel101;
	}
	/**
	 * This method initializes jLabel24
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel102() {
		if(jLabel102 == null) {
			jLabel102 = new javax.swing.JLabel();
			jLabel102.setBounds(316, 404, 91, 24);
			jLabel102.setText("JLabel");
		}
		return jLabel102;
	}
	/**
	 * This method initializes jLabel25
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel103() {
		if(jLabel103 == null) {
			jLabel103 = new javax.swing.JLabel();
			jLabel103.setBounds(316, 439, 91, 24);
			jLabel103.setText("JLabel");
		}
		return jLabel103;
	}
	/**
	 * This method initializes jTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField78() {
		if(jTextField78 == null) {
			jTextField78 = new javax.swing.JTextField();
			jTextField78.setNextFocusableComponent(getJTextField79());
			jTextField78.setBounds(117, 19, 177, 24);
		}
		return jTextField78;
	}
	/**
	 * This method initializes jTextField1
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField79() {
		if(jTextField79 == null) {
			jTextField79 = new javax.swing.JTextField();
			jTextField79.setNextFocusableComponent(getJTextField80());
			jTextField79.setBounds(117, 54, 177, 24);
		}
		return jTextField79;
	}
	/**
	 * This method initializes jTextField2
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField80() {
		if(jTextField80 == null) {
			jTextField80 = new javax.swing.JTextField();
			jTextField80.setNextFocusableComponent(getJTextField81());
			jTextField80.setBounds(117, 89, 177, 24);
		}
		return jTextField80;
	}
	/**
	 * This method initializes jTextField3
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField81() {
		if(jTextField81 == null) {
			jTextField81 = new javax.swing.JTextField();
			jTextField81.setNextFocusableComponent(getJTextField82());
			jTextField81.setBounds(117, 124, 177, 24);
		}
		return jTextField81;
	}
	/**
	 * This method initializes jTextField4
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField82() {
		if(jTextField82 == null) {
			jTextField82 = new javax.swing.JTextField();
			jTextField82.setNextFocusableComponent(getJTextField83());
			jTextField82.setBounds(117, 159, 177, 24);
		}
		return jTextField82;
	}
	/**
	 * This method initializes jTextField5
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField83() {
		if(jTextField83 == null) {
			jTextField83 = new javax.swing.JTextField();
			jTextField83.setNextFocusableComponent(getJTextField84());
			jTextField83.setBounds(117, 194, 177, 24);
		}
		return jTextField83;
	}
	/**
	 * This method initializes jTextField6
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField84() {
		if(jTextField84 == null) {
			jTextField84 = new javax.swing.JTextField();
			jTextField84.setNextFocusableComponent(getJTextField85());
			jTextField84.setBounds(117, 229, 177, 24);
		}
		return jTextField84;
	}
	/**
	 * This method initializes jTextField7
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField85() {
		if(jTextField85 == null) {
			jTextField85 = new javax.swing.JTextField();
			jTextField85.setNextFocusableComponent(getJTextField86());
			jTextField85.setBounds(117, 264, 177, 24);
		}
		return jTextField85;
	}
	/**
	 * This method initializes jTextField8
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField86() {
		if(jTextField86 == null) {
			jTextField86 = new javax.swing.JTextField();
			jTextField86.setNextFocusableComponent(getJTextField87());
			jTextField86.setBounds(117, 299, 177, 24);
		}
		return jTextField86;
	}
	/**
	 * This method initializes jTextField9
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField87() {
		if(jTextField87 == null) {
			jTextField87 = new javax.swing.JTextField();
			jTextField87.setNextFocusableComponent(getJTextField88());
			jTextField87.setBounds(117, 334, 177, 24);
		}
		return jTextField87;
	}
	/**
	 * This method initializes jTextField10
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField88() {
		if(jTextField88 == null) {
			jTextField88 = new javax.swing.JTextField();
			jTextField88.setNextFocusableComponent(getJTextField89());
			jTextField88.setBounds(117, 369, 177, 24);
		}
		return jTextField88;
	}
	/**
	 * This method initializes jTextField11
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField89() {
		if(jTextField89 == null) {
			jTextField89 = new javax.swing.JTextField();
			jTextField89.setNextFocusableComponent(getJTextField90());
			jTextField89.setBounds(117, 404, 177, 24);
		}
		return jTextField89;
	}
	/**
	 * This method initializes jTextField12
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField90() {
		if(jTextField90 == null) {
			jTextField90 = new javax.swing.JTextField();
			jTextField90.setNextFocusableComponent(getJTextField91());
			jTextField90.setBounds(117, 439, 177, 24);
		}
		return jTextField90;
	}
	/**
	 * This method initializes jTextField13
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField91() {
		if(jTextField91 == null) {
			jTextField91 = new javax.swing.JTextField();
			jTextField91.setNextFocusableComponent(getJTextField92());
			jTextField91.setBounds(413, 19, 177, 24);
		}
		return jTextField91;
	}
	/**
	 * This method initializes jTextField14
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField92() {
		if(jTextField92 == null) {
			jTextField92 = new javax.swing.JTextField();
			jTextField92.setNextFocusableComponent(getJTextField93());
			jTextField92.setBounds(413, 54, 177, 24);
		}
		return jTextField92;
	}
	/**
	 * This method initializes jTextField15
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField93() {
		if(jTextField93 == null) {
			jTextField93 = new javax.swing.JTextField();
			jTextField93.setNextFocusableComponent(getJTextField94());
			jTextField93.setBounds(413, 89, 177, 24);
		}
		return jTextField93;
	}
	/**
	 * This method initializes jTextField16
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField94() {
		if(jTextField94 == null) {
			jTextField94 = new javax.swing.JTextField();
			jTextField94.setNextFocusableComponent(getJTextField95());
			jTextField94.setBounds(413, 124, 177, 24);
		}
		return jTextField94;
	}
	/**
	 * This method initializes jTextField17
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField95() {
		if(jTextField95 == null) {
			jTextField95 = new javax.swing.JTextField();
			jTextField95.setNextFocusableComponent(getJTextField96());
			jTextField95.setBounds(413, 159, 177, 24);
		}
		return jTextField95;
	}
	/**
	 * This method initializes jTextField18
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField96() {
		if(jTextField96 == null) {
			jTextField96 = new javax.swing.JTextField();
			jTextField96.setNextFocusableComponent(getJTextField97());
			jTextField96.setBounds(413, 194, 177, 24);
		}
		return jTextField96;
	}
	/**
	 * This method initializes jTextField19
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField97() {
		if(jTextField97 == null) {
			jTextField97 = new javax.swing.JTextField();
			jTextField97.setNextFocusableComponent(getJTextField98());
			jTextField97.setBounds(413, 229, 177, 24);
		}
		return jTextField97;
	}
	/**
	 * This method initializes jTextField20
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField98() {
		if(jTextField98 == null) {
			jTextField98 = new javax.swing.JTextField();
			jTextField98.setNextFocusableComponent(getJTextField99());
			jTextField98.setBounds(413, 264, 177, 24);
		}
		return jTextField98;
	}
	/**
	 * This method initializes jTextField21
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField99() {
		if(jTextField99 == null) {
			jTextField99 = new javax.swing.JTextField();
			jTextField99.setNextFocusableComponent(getJTextField100());
			jTextField99.setBounds(413, 299, 177, 24);
		}
		return jTextField99;
	}
	/**
	 * This method initializes jTextField100
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField100() {
		if(jTextField100 == null) {
			jTextField100 = new javax.swing.JTextField();
			jTextField100.setNextFocusableComponent(getJTextField101());
			jTextField100.setBounds(413, 334, 177, 24);
		}
		return jTextField100;
	}
	/**
	 * This method initializes jTextField23
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField101() {
		if(jTextField101 == null) {
			jTextField101 = new javax.swing.JTextField();
			jTextField101.setNextFocusableComponent(getJTextField102());
			jTextField101.setBounds(413, 369, 177, 24);
		}
		return jTextField101;
	}
	/**
	 * This method initializes jTextField24
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField102() {
		if(jTextField102 == null) {
			jTextField102 = new javax.swing.JTextField();
			jTextField102.setNextFocusableComponent(getJTextField103());
			jTextField102.setBounds(413, 404, 177, 24);
		}
		return jTextField102;
	}
	/**
	 * This method initializes jTextField25
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField103() {
		if(jTextField103 == null) {
			jTextField103 = new javax.swing.JTextField();
			jTextField103.setNextFocusableComponent(getJTextField104());
			jTextField103.setBounds(413, 439, 177, 24);
		}
		return jTextField103;
	}
	/**
	 * This method initializes jLabel26
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel104() {
		if(jLabel104 == null) {
			jLabel104 = new javax.swing.JLabel();
			jLabel104.setBounds(610, 19, 91, 24);
			jLabel104.setText("JLabel");
		}
		return jLabel104;
	}
	/**
	 * This method initializes jLabel27
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel105() {
		if(jLabel105 == null) {
			jLabel105 = new javax.swing.JLabel();
			jLabel105.setBounds(610, 54, 91, 24);
			jLabel105.setText("JLabel");
		}
		return jLabel105;
	}
	/**
	 * This method initializes jLabel28
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel106() {
		if(jLabel106 == null) {
			jLabel106 = new javax.swing.JLabel();
			jLabel106.setBounds(610, 89, 91, 24);
			jLabel106.setText("JLabel");
		}
		return jLabel106;
	}
	/**
	 * This method initializes jLabel29
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel107() {
		if(jLabel107 == null) {
			jLabel107 = new javax.swing.JLabel();
			jLabel107.setBounds(610, 124, 91, 24);
			jLabel107.setText("JLabel");
		}
		return jLabel107;
	}
	/**
	 * This method initializes jLabel30
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel108() {
		if(jLabel108 == null) {
			jLabel108 = new javax.swing.JLabel();
			jLabel108.setBounds(610, 159, 91, 24);
			jLabel108.setText("JLabel");
		}
		return jLabel108;
	}
	/**
	 * This method initializes jLabel31
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel109() {
		if(jLabel109 == null) {
			jLabel109 = new javax.swing.JLabel();
			jLabel109.setBounds(610, 194, 91, 24);
			jLabel109.setText("JLabel");
		}
		return jLabel109;
	}
	/**
	 * This method initializes jLabel32
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel110() {
		if(jLabel110 == null) {
			jLabel110 = new javax.swing.JLabel();
			jLabel110.setBounds(610, 229, 91, 24);
			jLabel110.setText("JLabel");
		}
		return jLabel110;
	}
	/**
	 * This method initializes jLabel33
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel111() {
		if(jLabel111 == null) {
			jLabel111 = new javax.swing.JLabel();
			jLabel111.setBounds(610, 264, 91, 24);
			jLabel111.setText("JLabel");
		}
		return jLabel111;
	}
	/**
	 * This method initializes jLabel34
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel112() {
		if(jLabel112 == null) {
			jLabel112 = new javax.swing.JLabel();
			jLabel112.setBounds(610, 299, 91, 24);
			jLabel112.setText("JLabel");
		}
		return jLabel112;
	}
	/**
	 * This method initializes jLabel35
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel113() {
		if(jLabel113 == null) {
			jLabel113 = new javax.swing.JLabel();
			jLabel113.setBounds(610, 334, 91, 24);
			jLabel113.setText("JLabel");
		}
		return jLabel113;
	}
	/**
	 * This method initializes jLabel36
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel114() {
		if(jLabel114 == null) {
			jLabel114 = new javax.swing.JLabel();
			jLabel114.setBounds(610, 369, 91, 24);
			jLabel114.setText("JLabel");
		}
		return jLabel114;
	}
	/**
	 * This method initializes jLabel37
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel115() {
		if(jLabel115 == null) {
			jLabel115 = new javax.swing.JLabel();
			jLabel115.setBounds(610, 404, 91, 24);
			jLabel115.setText("JLabel");
		}
		return jLabel115;
	}
	/**
	 * This method initializes jLabel38
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel116() {
		if(jLabel116 == null) {
			jLabel116 = new javax.swing.JLabel();
			jLabel116.setBounds(610, 439, 91, 24);
			jLabel116.setText("JLabel");
		}
		return jLabel116;
	}
	/**
	 * This method initializes jTextField26
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField104() {
		if(jTextField104 == null) {
			jTextField104 = new javax.swing.JTextField();
			jTextField104.setNextFocusableComponent(getJTextField105());
			jTextField104.setBounds(708, 19, 177, 24);
		}
		return jTextField104;
	}
	/**
	 * This method initializes jTextField27
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField105() {
		if(jTextField105 == null) {
			jTextField105 = new javax.swing.JTextField();
			jTextField105.setNextFocusableComponent(getJTextField106());
			jTextField105.setBounds(708, 54, 177, 24);
		}
		return jTextField105;
	}
	/**
	 * This method initializes jTextField28
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField106() {
		if(jTextField106 == null) {
			jTextField106 = new javax.swing.JTextField();
			jTextField106.setNextFocusableComponent(getJTextField107());
			jTextField106.setBounds(708, 89, 177, 24);
		}
		return jTextField106;
	}
	/**
	 * This method initializes jTextField29
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField107() {
		if(jTextField107 == null) {
			jTextField107 = new javax.swing.JTextField();
			jTextField107.setNextFocusableComponent(getJTextField108());
			jTextField107.setBounds(708, 124, 177, 24);
		}
		return jTextField107;
	}
	/**
	 * This method initializes jTextField30
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField108() {
		if(jTextField108 == null) {
			jTextField108 = new javax.swing.JTextField();
			jTextField108.setNextFocusableComponent(getJTextField109());
			jTextField108.setBounds(708, 159, 177, 24);
		}
		return jTextField108;
	}
	/**
	 * This method initializes jTextField31
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField109() {
		if(jTextField109 == null) {
			jTextField109 = new javax.swing.JTextField();
			jTextField109.setNextFocusableComponent(getJTextField110());
			jTextField109.setBounds(708, 194, 177, 24);
		}
		return jTextField109;
	}
	/**
	 * This method initializes jTextField32
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField110() {
		if(jTextField110 == null) {
			jTextField110 = new javax.swing.JTextField();
			jTextField110.setNextFocusableComponent(getJTextField111());
			jTextField110.setBounds(708, 229, 177, 24);
		}
		return jTextField110;
	}
	/**
	 * This method initializes jTextField33
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField111() {
		if(jTextField111 == null) {
			jTextField111 = new javax.swing.JTextField();
			jTextField111.setNextFocusableComponent(getJTextField112());
			jTextField111.setBounds(708, 264, 177, 24);
		}
		return jTextField111;
	}
	/**
	 * This method initializes jTextField34
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField112() {
		if(jTextField112 == null) {
			jTextField112 = new javax.swing.JTextField();
			jTextField112.setNextFocusableComponent(getJTextField113());
			jTextField112.setBounds(708, 299, 177, 24);
		}
		return jTextField112;
	}
	/**
	 * This method initializes jTextField35
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField113() {
		if(jTextField113 == null) {
			jTextField113 = new javax.swing.JTextField();
			jTextField113.setNextFocusableComponent(getJTextField114());
			jTextField113.setBounds(708, 334, 177, 24);
		}
		return jTextField113;
	}
	/**
	 * This method initializes jTextField36
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField114() {
		if(jTextField114 == null) {
			jTextField114 = new javax.swing.JTextField();
			jTextField114.setNextFocusableComponent(getJTextField115());
			jTextField114.setBounds(708, 369, 177, 24);
		}
		return jTextField114;
	}
	/**
	 * This method initializes jTextField37
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField115() {
		if(jTextField115 == null) {
			jTextField115 = new javax.swing.JTextField();
			jTextField115.setNextFocusableComponent(getJTextField116());
			jTextField115.setBounds(708, 404, 177, 24);
		}
		return jTextField115;
	}
	/**
	 * This method initializes jTextField38
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField116() {
		if(jTextField116 == null) {
			jTextField116 = new javax.swing.JTextField();
			jTextField116.setNextFocusableComponent(getJButton());
			jTextField116.setBounds(708, 439, 177, 24);
		}
		return jTextField116;
	}	
	
	private javax.swing.JButton getJButton6() {
		if(jButton6 == null) {
			jButton6 = new javax.swing.JButton();
			jButton6.setBounds(784, 598, 141, 23);
			jButton6.setText("Next");
			jButton6.setVisible(false);
			jButton6.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					jPanel1.setVisible(false);
					jPanel2.setVisible(false);
					jPanel3.setVisible(true);
					jButton.setVisible(false);
					jButton1.setVisible(true);
					jButton5.setVisible(false);
					jButton3.setVisible(false);
					jButton4.setVisible(false);
					jButton2.setVisible(false);
					jButton6.setVisible(false);
					jButton7.setVisible(true);

				}
			});
		}
		return jButton6;
	}
	/**
	 * This method initializes jButton5
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton7() {
		if(jButton7 == null) {
			jButton7 = new javax.swing.JButton();
			jButton7.setBounds(17, 598, 141, 23);
			jButton7.setText("Back");
			jButton7.setVisible(false);
			jButton7.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					jPanel1.setVisible(false);
					jPanel2.setVisible(true);
					jPanel3.setVisible(false);
					jButton.setVisible(false);
					jButton4.setVisible(true);
					jButton2.setVisible(false);
					jButton3.setVisible(false);
					jButton5.setVisible(true);
					jButton1.setVisible(false);
				}
			});
		}
		return jButton7;
	}


}  //  @jve:visual-info  decl-index=0 visual-constraint="10,10"
